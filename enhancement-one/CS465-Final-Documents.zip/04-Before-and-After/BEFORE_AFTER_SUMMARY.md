# Travlr Getaways Before-and-After Summary

| Area | Original artifact | Enhanced artifact |
|---|---|---|
| Trip discovery | Static trip catalog without customer-controlled search, price/date ranges, or explicit sorting | Combined validated search and filters with retained criteria and deterministic sorting |
| Price handling | Basic per-person field without evidence of exact storage or malformed-value rejection | Exact MongoDB Decimal128 storage, strict two-decimal validation, and tested numeric sorting/filtering |
| Customer communication | No trip-linked inquiry or confirmation workflow | Validated inquiry form, generated reference, signed receipt, and confirmation page |
| Administrator workflow | Trip add, edit, and delete operations | Trip management plus protected inquiry inbox, pagination, filtering, and status updates |
| Authorization | Login supported administration, but retained screenshots did not demonstrate current-role authorization | JWT authentication followed by a current MongoDB role check on every protected request |
| Failure handling | Limited evidence of rejected or failed requests | Safe 400, 401, 403, 404, and 503 paths verified by automated tests |
| Testing evidence | Screenshots primarily demonstrated CRUD use | Backend unit, Angular, price/CRUD, search, inquiry, and staff integration suites all passed |

Only two useful original screenshots were retained. The verified original source code supplies the baseline for behavior that was not captured visually.

