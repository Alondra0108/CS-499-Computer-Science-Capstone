# CS 465 Capstone Enhancement Evidence Index

**Artifact:** Travlr Getaways Full-Stack Application  
**Category:** Software Design and Engineering  
**Student:** Alondra Paulino Santos

## Purpose

This index organizes evidence for the CS 465 software design and engineering enhancement. Each item should demonstrate a specific implemented improvement or verified test result. Evidence will be referenced in the final enhancement narrative, software design document, and CS 499 ePortfolio.

## Evidence Status Key

- `[ ]` Not yet captured
- `[x]` Captured and reviewed
- `[N/A]` Not required or not applicable

## 01 — Original Application

Place screenshots from the original software design document or original application in `01-Original-Application`.

- [N/A] `01-original-trip-list.png` — No original public-page screenshot was retained; original behavior will be documented from the submitted artifact and contrasted with enhanced functional/test evidence
- [x] `02-original-admin-page.png` — Original administrator trip-management interface
- [ ] `03-original-design-diagram.png` — Original architecture or design diagram
- [x] `04-original-edit-form-limitations.png` — Original edit form before strengthened price validation, safe description handling, and documented tests

## 02 — Enhanced Application

Place new functional screenshots in `02-Enhanced-Application`.

- [x] `01-enhanced-trip-search.png` — Search and filtering controls
- [x] `02-enhanced-filter-results.png` — Filtered trip results with numeric currency display
- [x] `03-customer-inquiry-form.png` — Trip-specific inquiry form and traveler count
- [x] `04-inquiry-validation-errors.png` — Rejected invalid inquiry fields; supplemental required-name example also captured
- [x] `05-inquiry-confirmation.png` — Confirmation page with generated reference number
- [x] `06-staff-inquiry-inbox.png` — Protected administrator inquiry list
- [x] `07-staff-status-filter-and-update.png` — Status filter returns the matching inquiry and confirms the saved `In progress` status
- [N/A] Separate `08-staff-status-update.png` — Combined clearly with item 07 to avoid duplicate evidence
- [ ] `09-unauthorized-access.png` — Optional clear evidence of rejected unauthorized access

## 03 — Automated Testing

Place terminal screenshots and saved test summaries in `03-Automated-Testing`.

- [x] `01-backend-unit-tests.png` — 15 of 15 tests passed
- [x] `02-angular-tests.png` — 16 of 16 tests passed
- [x] `03-price-integration.png` — Numeric price and CRUD integration suite passed
- [x] `04-search-integration.png` — Search and filtering integration suite passed
- [x] `05-inquiry-integration.png` — Customer inquiry integration suite passed; receipt token redacted
- [x] `06-staff-integration.png` — Authorization and inquiry-management suite passed
- [x] `TEST_RESULTS.md` — Written summary of commands, results, and what each suite verifies

## 04 — Before and After

Place combined comparisons in `04-Before-and-After`.

- [N/A] Separate `01-trip-discovery-before-after.png` — Comparison is documented in the narrative, design document, original screenshots, and enhanced screenshots
- [N/A] Separate `02-inquiry-workflow-before-after.png` — The original artifact had no inquiry workflow; enhanced functional and test evidence documents the addition
- [N/A] Separate `03-administrator-workflow-before-after.png` — Original and enhanced administrator evidence is already included without creating a duplicate composite
- [x] `BEFORE_AFTER_SUMMARY.md` — Concise comparison table for the narrative and portfolio

## 05 — Code Evidence

This folder contains the verified original source and the completed enhanced source. Dependencies, secrets, Git metadata, caches, and compiled output are excluded.

- [x] `01-Original-Source` — Original CS 465 source verified against `cs465-fullstack.zip`
- [x] `02-Enhanced-Source` — Completed capstone enhancement source
- [x] Numeric `Decimal128` trip-price model and JSON conversion included in enhanced source
- [x] Search validation and MongoDB query construction included in enhanced source
- [x] Inquiry server-side validation rules included in enhanced source
- [x] Generated customer reference number and inquiry schema included in enhanced source
- [x] JWT-protected routes and current staff-role authorization included in enhanced source
- [x] Paginated inquiry list and allowlisted status update included in enhanced source

## 06 — Final Documents

Place final documents in `06-Final-Documents` after evidence is complete.

- [x] Final enhancement narrative
- [x] Final enhanced software design document
- [x] PDF copies for reliable portfolio viewing

## Verified Results Already Confirmed

The following results were verified on October 10, 2026, from the enhanced Desktop project:

- Backend unit tests: **15 passed, 0 failed**
- Angular tests: **16 passed, 0 failed**
- Price and CRUD integration suite: **passed**
- Search and filter integration suite: **passed**
- Customer inquiry integration suite: **passed**
- Staff authorization and inquiry-management integration suite: **passed**

All six automated-testing screenshots have been captured, reviewed, and placed in the evidence folder.

## Evidence Quality Checklist

Before marking an item complete, confirm that:

- The important feature or result is readable.
- No password, JWT, database connection string, or other secret is visible.
- No unnecessary browser tabs, notifications, or personal information are visible.
- The image filename matches this index.
- The caption explains what the evidence proves.
- Written claims match the verified implementation and test results.
