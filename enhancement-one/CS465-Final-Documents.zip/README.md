# CS 465 Software Design and Engineering Enhancement

This folder contains the complete evidence package for the CS 499 Enhancement One artifact, Travlr Getaways.

## Folder contents

- `01-Original-Application` — retained screenshots from the original CS 465 artifact
- `02-Enhanced-Application` — functional screenshots of the enhanced customer and staff workflows
- `03-Automated-Testing` — backend, Angular, and MongoDB integration-test evidence
- `04-Before-and-After` — concise comparison of the original and enhanced artifact
- `05-Code-Evidence/01-Original-Source` — verified original CS 465 source code
- `05-Code-Evidence/02-Enhanced-Source` — completed capstone enhancement source code
- `06-Final-Documents` — Enhancement One narrative and revised software design document
- `EVIDENCE_INDEX.md` — evidence checklist and figure descriptions

## Source-code note

Dependencies, Git history, local environment files, framework caches, and compiled output were intentionally excluded. Run `npm install` in a source folder to restore dependencies from `package-lock.json`. Local secrets must be supplied through a new `.env` file and should never be submitted.

