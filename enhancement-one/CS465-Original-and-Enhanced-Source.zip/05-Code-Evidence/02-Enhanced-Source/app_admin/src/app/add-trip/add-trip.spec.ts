import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddTrip } from './add-trip';
import { Router } from '@angular/router';
import { of } from 'rxjs';
import { TripData } from '../services/trip-data';

describe('AddTrip', () => {
  let component: AddTrip;
  let fixture: ComponentFixture<AddTrip>;
  const addTrip = vi.fn((trip) => of(trip));

  beforeEach(async () => {
    addTrip.mockClear();
    await TestBed.configureTestingModule({
      imports: [AddTrip],
      providers: [
        { provide: Router, useValue: { navigate: vi.fn() } },
        { provide: TripData, useValue: { addTrip } },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(AddTrip);
    component = fixture.componentInstance;
    fixture.detectChanges();
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('turns a typed dollar amount into a numeric form value and submits it', () => {
    component.addForm.patchValue({ code: 'TEST', name: 'Test', length: '2 days', start: '2026-10-01', resort: 'Test', image: 'reef.jpg', description: 'Test' });
    const input: HTMLInputElement = fixture.nativeElement.querySelector('#perPerson');
    expect(input.type).toBe('number');
    input.value = '125.50';
    input.dispatchEvent(new Event('input'));
    expect(component.addForm.controls['perPerson'].value).toBe(125.5);
    component.onSubmit();
    expect(addTrip).toHaveBeenCalledOnce();
    expect(addTrip.mock.calls[0][0].perPerson).toBe(125.5);
  });

  it('does not submit a negative or fractional-cent price', () => {
    component.addForm.patchValue({ code: 'TEST', name: 'Test', length: '2 days', start: '2026-10-01', resort: 'Test', image: 'reef.jpg', description: 'Test' });
    for (const value of [-1, 1.001, null]) {
      component.addForm.controls['perPerson'].setValue(value);
      component.onSubmit();
    }
    expect(addTrip).not.toHaveBeenCalled();
  });
});
