export const trips = [
  {
    code: 'GALR210214',
    name: 'Gale Reef',
    length: '4 nights / 5 days',
    start: '2021-02-14T08:00:00.000Z',
    resort: 'Emerald Bay, 3 stars',
    perPerson: 799.00,
    image: 'images/reef1.jpg',
    description:
      '<p>Sed et augue lorem. In sit amet placerat arcu. Mauris volutpat ipsum ac justo mollis vel vestibulum orci gravida. Vestibulum sit amet porttitor odio. Nulla facilisi. Fusce at pretium felis.</p><p>Sed consequat libero ut turpis venenatis ut aliquam risus semper. Etiam convallis mi vel risus pretium sodales. Etiam nunc lorem ullamcorper vitae laoreet.</p>',
  },
  {
    code: 'DAWR210315',
    name: 'Dawson’s Reef',
    length: '4 nights / 5 days',
    start: '2021-03-15T08:00:00.000Z',
    resort: 'Blue Lagoon, 4 stars',
    perPerson: 1199.00,
    image: 'images/reef2.jpg',
    description:
      '<p>Integer magna leo, posuere et dignissim vitae, porttitor at odio. Pellentesque a metus nec magna placerat volutpat. Nunc nisi mi, elementum sit amet aliquet quis, tristique quis nisl. Curabitur odio lacus, blandit ut hendrerit.</p><p>Vulputate, vulputate at est. Morbi aliquet viverra metus eu consectetur. In lorem dui, elementum sit amet convallis ac, tincidunt vel sapien.</p>',
  },
  {
    code: 'CLAR210621',
    name: 'Claire’s Reef',
    length: '4 nights / 5 days',
    start: '2021-06-21T08:00:00.000Z',
    resort: 'Coral Sands, 5 stars',
    perPerson: 1999.00,
    image: 'images/reef3.jpg',
    description:
      '<p>Donec sed felis risus. Nulla facilisi. Donec a orci tellus, et auctor odio. Fusce ac orci nibh, quis semper arcu. Cras orci neque, euismod et accumsan ac, sagittis molestie lorem. Proin odio sapien, elementum at tempor non.</p><p>Vulputate eget libero. In hac habitasse platea dictumst. Integer purus justo, egestas eu consectetur eu, cursus in tortor. Quisque nec nunc ac mi ultrices iaculis.</p>',
  },
];
