import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';

import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';
import { EditTrip } from './edit-trip';

describe('EditTrip', () => {
  let component: EditTrip;
  let fixture: ComponentFixture<EditTrip>;
  const updateTrip = vi.fn((trip: Trip) => of(trip));

  const testTrip: Trip = {
    code: 'TEST',
    name: 'Test Trip',
    length: '2 nights / 3 days',
    start: '2026-08-15',
    resort: 'Test Resort',
    perPerson: 500,
    image: 'reef1.jpg',
    description: 'Test description',
  };

  beforeEach(async () => {
    updateTrip.mockClear();
    Object.defineProperty(globalThis, 'localStorage', {
      configurable: true,
      value: {
        getItem: (key: string) => key === 'tripCode' ? 'TEST' : null,
        setItem: () => undefined,
        removeItem: () => undefined,
        clear: () => undefined,
        key: () => null,
        length: 1,
      } as Storage,
    });

    await TestBed.configureTestingModule({
      imports: [EditTrip],
      providers: [
        provideRouter([]),
        {
          provide: TripData,
          useValue: { getTrip: () => of([testTrip]), updateTrip },
        },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(EditTrip);
    component = fixture.componentInstance;
    fixture.detectChanges();
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('loads a numeric price and submits an edited numeric price', () => {
    expect(component.editForm.controls['perPerson'].value).toBe(500);
    const input: HTMLInputElement = fixture.nativeElement.querySelector('#perPerson');
    input.value = '99.99';
    input.dispatchEvent(new Event('input'));
    component.onSubmit();
    expect(updateTrip).toHaveBeenCalledOnce();
    expect(updateTrip.mock.calls[0][0].perPerson).toBe(99.99);
  });

  it('blocks a fractional-cent edit', () => {
    component.editForm.controls['perPerson'].setValue(1.001);
    component.onSubmit();
    expect(updateTrip).not.toHaveBeenCalled();
  });
});
