import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';

import { Inquiry, InquiryPage } from '../models/inquiry';
import { InquiryData } from '../services/inquiry-data';
import { InquiryList } from './inquiry-list';

describe('InquiryList', () => {
  const inquiry: Inquiry = {
    _id: '507f1f77bcf86cd799439011', referenceNumber: 'INQ-20260918-A1B2C3D4', tripCode: 'REEF', tripName: 'Reef Escape',
    fullName: 'Customer Name', email: 'customer@example.test',
    travelerCount: 4, message: 'Can I travel with my family?', status: 'new', createdAt: '2026-09-17T12:00:00Z'
  };
  const page: InquiryPage = { items: [inquiry], total: 1, page: 1, pageSize: 20, pageCount: 1 };
  const list = vi.fn(() => of(page));
  const changeStatus = vi.fn(() => of({ ...inquiry, status: 'closed' as const }));

  beforeEach(async () => {
    list.mockClear();
    changeStatus.mockClear();
    await TestBed.configureTestingModule({
      imports: [InquiryList],
      providers: [{ provide: InquiryData, useValue: { list, changeStatus } }]
    }).compileComponents();
  });

  it('shows the trip, customer question, and current status', async () => {
    const fixture = TestBed.createComponent(InquiryList);
    fixture.detectChanges();
    await fixture.whenStable();
    expect(fixture.nativeElement.textContent).toContain('Reef Escape');
    expect(fixture.nativeElement.textContent).toContain('Can I travel with my family?');
    expect(fixture.nativeElement.textContent).toContain('Current status: New');
    expect(fixture.nativeElement.textContent).toContain('INQ-20260918-A1B2C3D4');
    expect(fixture.nativeElement.textContent).toContain('Travelers: 4');
  });

  it('updates a status only when Save status is requested', async () => {
    const fixture = TestBed.createComponent(InquiryList);
    fixture.detectChanges();
    await fixture.whenStable();
    const component = fixture.componentInstance;
    component.draftStatus[inquiry._id] = 'closed';
    expect(changeStatus).not.toHaveBeenCalled();
    component.saveStatus(inquiry);
    expect(changeStatus).toHaveBeenCalledWith(inquiry._id, 'closed');
    expect(component.inquiries[0].status).toBe('closed');
  });
});
