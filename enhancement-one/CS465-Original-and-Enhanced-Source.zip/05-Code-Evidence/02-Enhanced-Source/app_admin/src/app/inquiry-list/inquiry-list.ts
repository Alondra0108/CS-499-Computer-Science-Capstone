import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { Inquiry, InquiryStatus } from '../models/inquiry';
import { InquiryData } from '../services/inquiry-data';

/** Review customer questions and deliberately save each status change. */
@Component({
  selector: 'app-inquiry-list',
  imports: [CommonModule, FormsModule],
  templateUrl: './inquiry-list.html',
  styleUrl: './inquiry-list.css',
})
export class InquiryList implements OnInit {
  private requestVersion = 0;
  inquiries: Inquiry[] = [];
  draftStatus: Record<string, InquiryStatus> = {};
  filterStatus: InquiryStatus | '' = '';
  page = 1;
  pageCount = 1;
  total = 0;
  loading = false;
  updatingId = '';
  message = '';
  itemErrors: Record<string, string> = {};

  constructor(private readonly data: InquiryData, private readonly changeDetector: ChangeDetectorRef) {}

  ngOnInit(): void { this.load(); }

  applyFilter(): void {
    this.page = 1;
    this.load();
  }

  goToPage(page: number): void {
    if (page < 1 || page > this.pageCount || this.loading) return;
    this.page = page;
    this.load();
  }

  load(): void {
    const request = ++this.requestVersion;
    this.loading = true;
    this.message = '';
    this.itemErrors = {};
    this.data.list(this.page, this.filterStatus).subscribe({
      next: result => {
        if (request !== this.requestVersion) return;
        this.inquiries = result.items;
        this.total = result.total;
        this.page = result.page;
        this.pageCount = result.pageCount;
        this.draftStatus = Object.fromEntries(result.items.map(item => [item._id, item.status]));
        this.loading = false;
        this.changeDetector.detectChanges();
      },
      error: () => {
        if (request !== this.requestVersion) return;
        this.inquiries = [];
        this.loading = false;
        this.message = 'Unable to load inquiries. Please try again.';
        this.changeDetector.detectChanges();
      },
    });
  }

  saveStatus(inquiry: Inquiry): void {
    const status = this.draftStatus[inquiry._id];
    if (!status || status === inquiry.status || this.updatingId) return;
    this.updatingId = inquiry._id;
    delete this.itemErrors[inquiry._id];
    this.data.changeStatus(inquiry._id, status).subscribe({
      next: updated => {
        this.inquiries = this.inquiries.map(item => item._id === updated._id ? updated : item);
        this.draftStatus[updated._id] = updated.status;
        this.updatingId = '';
        // A filtered inbox should immediately remove items moved to another status.
        if (this.filterStatus && updated.status !== this.filterStatus) this.load();
        else this.changeDetector.detectChanges();
      },
      error: () => {
        this.itemErrors[inquiry._id] = 'Status was not saved. Please try again.';
        this.updatingId = '';
        this.changeDetector.detectChanges();
      },
    });
  }

  statusLabel(status: InquiryStatus): string {
    return { new: 'New', in_progress: 'In progress', closed: 'Closed' }[status];
  }
}
