/** Staff view of a customer question; email and message never enter public APIs. */
export type InquiryStatus = 'new' | 'in_progress' | 'closed';

export interface Inquiry {
  _id: string;
  referenceNumber: string;
  tripCode: string;
  tripName: string;
  fullName: string;
  email: string;
  travelerCount: number;
  message: string;
  status: InquiryStatus;
  createdAt: string;
}

export interface InquiryPage {
  items: Inquiry[];
  total: number;
  page: number;
  pageSize: number;
  pageCount: number;
}
