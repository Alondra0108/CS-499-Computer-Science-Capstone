import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { Inquiry, InquiryPage, InquiryStatus } from '../models/inquiry';

/** Staff-only API calls; the server enforces the role on every request. */
@Injectable({ providedIn: 'root' })
export class InquiryData {
  private readonly apiUrl = 'http://localhost:3000/api/inquiries';

  constructor(private readonly http: HttpClient) {}

  list(page: number, status: InquiryStatus | ''): Observable<InquiryPage> {
    let params = new HttpParams().set('page', page);
    if (status) params = params.set('status', status);
    return this.http.get<InquiryPage>(this.apiUrl, { params });
  }

  changeStatus(id: string, status: InquiryStatus): Observable<Inquiry> {
    return this.http.patch<Inquiry>(`${this.apiUrl}/${encodeURIComponent(id)}/status`, { status });
  }
}
