import { FormControl, Validators } from '@angular/forms';
import { MAX_PRICE, priceValidator } from './price';

describe('priceValidator', () => {
  it('accepts zero, whole dollars, cents and the upper bound', () => {
    for (const value of [0, 0.01, 0.1, 19.99, 799, MAX_PRICE]) {
      expect(new FormControl(value, [Validators.required, priceValidator]).valid).toBe(true);
    }
  });
  it('rejects blank, negative, fractional-cent, nonnumeric and oversized values', () => {
    for (const value of [null, '', '12', true, NaN, Infinity, -1, 0.001, MAX_PRICE + 1]) {
      expect(new FormControl(value, [Validators.required, priceValidator]).valid).toBe(false);
    }
  });
});
