/** CS 499 | Alondra Paulino Santos | 2026-09-17: mirror the API's USD rules. */
import { AbstractControl, ValidationErrors } from '@angular/forms';

export const MAX_PRICE = 999999999.99;

export function priceValidator(control: AbstractControl): ValidationErrors | null {
  const value: unknown = control.value;
  // Required validation handles an untouched or cleared number input.
  if (value === null || value === undefined || value === '') return null;
  return typeof value === 'number' && Number.isFinite(value) &&
    value >= 0 && value <= MAX_PRICE && /^\d+(?:\.\d{1,2})?$/.test(String(value))
      ? null : { price: true };
}
