/**
 * CS 499 | Alondra Paulino Santos | 2026-09-17
 * Staff-only inbox and status updates. Each query and update uses an explicit
 * allowlist; customers cannot read messages or set workflow fields.
 */
const mongoose = require('mongoose');
const Inquiry = require('../models/inquiry');
const STATUSES = ['new', 'in_progress', 'closed'];
const PAGE_SIZE = 20;

async function list(req, res) {
  const { status, page = '1' } = req.query;
  if (status !== undefined && (typeof status !== 'string' || !STATUSES.includes(status))) {
    return res.status(400).json({ message: 'Choose a listed inquiry status.' });
  }
  if (typeof page !== 'string' || !/^[1-9]\d{0,5}$/.test(page) || Object.keys(req.query).some(key => !['status', 'page'].includes(key))) {
    return res.status(400).json({ message: 'Invalid inquiry page or filter.' });
  }
  const pageNumber = Number(page);
  const filter = status ? { status } : {};
  try {
    const [items, total] = await Promise.all([
      Inquiry.find(filter).select('referenceNumber tripCode tripName fullName email travelerCount message status createdAt')
        .sort({ createdAt: -1, _id: -1 }).skip((pageNumber - 1) * PAGE_SIZE)
        .limit(PAGE_SIZE).maxTimeMS(3000).lean().exec(),
      Inquiry.countDocuments(filter).maxTimeMS(3000).exec()
    ]);
    return res.status(200).json({ items, total, page: pageNumber, pageSize: PAGE_SIZE, pageCount: Math.max(1, Math.ceil(total / PAGE_SIZE)) });
  } catch (error) {
    console.error('[inquiries] List failed', { name: error.name });
    return res.status(503).json({ message: 'Unable to retrieve inquiries. Please try again.' });
  }
}

async function changeStatus(req, res) {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid inquiry ID.' });
  if (!req.body || Object.keys(req.body).length !== 1 || !STATUSES.includes(req.body.status)) {
    return res.status(400).json({ message: 'Choose a listed status. Only status may be changed.' });
  }
  try {
    const inquiry = await Inquiry.findByIdAndUpdate(req.params.id, { $set: { status: req.body.status } }, { returnDocument: 'after', runValidators: true }).exec();
    if (!inquiry) return res.status(404).json({ message: 'Inquiry not found.' });
    return res.status(200).json(inquiry);
  } catch (error) {
    console.error('[inquiries] Status update failed', { name: error.name });
    return res.status(503).json({ message: 'Unable to update the inquiry. Please try again.' });
  }
}

module.exports = { list, changeStatus };
