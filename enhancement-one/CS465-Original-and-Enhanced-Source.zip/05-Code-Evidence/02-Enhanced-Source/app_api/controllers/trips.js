/**
 * Trip API | CS 499, Alondra Paulino Santos | Updated 2026-09-17.
 * The list endpoint validates search criteria and distinguishes empty results
 * from failed queries. Existing single-trip CRUD operations remain separate.
 */
const mongoose = require('mongoose');
const Trip = mongoose.model('trips');
const { isApiPrice, PRICE_MESSAGE } = require('../utils/price');
const { buildTripSearch, SearchValidationError } = require('../utils/trip-search');

/**
 * GET /api/trips: 200 plus an array (including []); 400 for invalid criteria;
 * 503 if retrieval fails. Retain the array contract used by the Angular client.
 */
const tripsList = async (req, res) => {
  try {
    const { filter, sort } = buildTripSearch(req.query);
    const trips = await Trip.find(filter).sort(sort).maxTimeMS(3000).exec();
    return res.status(200).json(trips);
  } catch (err) {
    if (err instanceof SearchValidationError) {
      return res.status(400).json({ message: err.message, errors: err.errors });
    }
    // No submitted search text, credentials or raw database messages in logs/UI.
    console.error('[trip-search] Database request failed', { name: err.name, code: err.code });
    return res.status(503).json({ message: 'Unable to retrieve trips. Please try again.' });
  }
};

// GET: /api/trips/:tripCode
// Returns the trip matching the supplied code.
const tripsFindByCode = async (req, res) => {
  try {
    const trips = await Trip
      .find({ code: req.params.tripCode })
      .exec();

    if (!trips || trips.length === 0) {
      return res
        .status(404)
        .json({
          message: `No trip found with code ${req.params.tripCode}`
        });
    }

    return res
      .status(200)
      .json(trips);
  } catch (err) {
    console.error('[trip-read] Request failed', { name: err.name, code: err.code });
    return res.status(503).json({ message: 'Unable to retrieve the trip. Please try again.' });
  }
};

// POST: /api/trips
// Creates and saves a new trip.
const tripsAddTrip = async (req, res) => {
  // Validate before Mongoose casting: blanks, booleans and strings are not prices.
  if (!isApiPrice(req.body?.perPerson)) {
    return res.status(400).json({ message: PRICE_MESSAGE });
  }
  try {
    const newTrip = new Trip({
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: req.body.start,
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image,
      description: req.body.description
    });

    const trip = await newTrip.save();

    if (!trip) {
      return res
        .status(400)
        .json({ message: 'Unable to create trip' });
    }

    return res
      .status(201)
      .json(trip);
  } catch (err) {
    // Log diagnostic metadata while keeping database details out of the API.
    console.error('[trip-create] Request failed', { name: err.name, code: err.code });
    return res.status(400).json({ message: 'Unable to create the trip. Check the submitted fields.' });
  }
};

// PUT: /api/trips/:tripCode
// Updates an existing trip.
const tripsUpdateTrip = async (req, res) => {
  if (!isApiPrice(req.body?.perPerson)) {
    return res.status(400).json({ message: PRICE_MESSAGE });
  }
  try {
    const trip = await Trip
      .findOneAndUpdate(
        { code: req.params.tripCode },
        {
          code: req.body.code,
          name: req.body.name,
          length: req.body.length,
          start: req.body.start,
          resort: req.body.resort,
          perPerson: req.body.perPerson,
          image: req.body.image,
          description: req.body.description
        },
        {
          // Mongoose 9 uses the MongoDB driver's explicit option name.
          returnDocument: 'after',
          runValidators: true
        }
      )
      .exec();

    if (!trip) {
      return res
        .status(400)
        .json({
          message: `No trip found with code ${req.params.tripCode}`
        });
    }

    return res
      .status(201)
      .json(trip);
  } catch (err) {
    console.error('[trip-update] Request failed', { name: err.name, code: err.code });
    return res.status(400).json({ message: 'Unable to update the trip. Check the submitted fields.' });
  }
};

// DELETE: /api/trips/:tripCode
// Deletes the trip matching the supplied code.
const tripsDeleteTrip = async (req, res) => {
  try {
    const trip = await Trip
      .findOneAndDelete({ code: req.params.tripCode })
      .exec();

    if (!trip) {
      return res
        .status(404)
        .json({
          message: `No trip found with code ${req.params.tripCode}`
        });
    }

    return res
      .status(200)
      .json(trip);
  } catch (err) {
    console.error('[trip-delete] Request failed', { name: err.name, code: err.code });
    return res.status(503).json({ message: 'Unable to delete the trip. Please try again.' });
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};
