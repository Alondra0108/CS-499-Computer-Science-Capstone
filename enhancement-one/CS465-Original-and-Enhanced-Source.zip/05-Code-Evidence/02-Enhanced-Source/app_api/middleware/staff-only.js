/**
 * CS 499 | Alondra Paulino Santos | 2026-09-17
 * Authentication proves who sent a request. Authorization checks the user's
 * current database role, so a stale token cannot retain revoked staff access.
 */
const mongoose = require('mongoose');
const User = require('../models/user');

async function staffOnly(req, res, next) {
  const id = req.auth?._id;
  if (!mongoose.isValidObjectId(id)) return res.status(403).json({ message: 'Staff access is required.' });
  try {
    const user = await User.findById(id).select('role').lean().exec();
    if (user?.role !== 'staff') return res.status(403).json({ message: 'Staff access is required.' });
    next();
  } catch (error) {
    console.error('[staff-auth] Role lookup failed', { name: error.name });
    return res.status(503).json({ message: 'Unable to verify access. Please try again.' });
  }
}

module.exports = staffOnly;
