/**
 * CS 499 | Alondra Paulino Santos | 2026-09-17
 * Store customer questions separately from trips. A trip-name snapshot keeps
 * an inquiry understandable if staff later edits the trip's display name.
 */
const mongoose = require('mongoose');
const { randomBytes } = require('node:crypto');

/** Create a short customer-facing identifier without exposing a database ID. */
function createReferenceNumber() {
  const date = new Date().toISOString().slice(0, 10).replaceAll('-', '');
  return `INQ-${date}-${randomBytes(4).toString('hex').toUpperCase()}`;
}

const inquirySchema = new mongoose.Schema({
  referenceNumber: { type: String, required: true, unique: true, immutable: true, default: createReferenceNumber },
  tripCode: { type: String, required: true, trim: true },
  tripName: { type: String, required: true, trim: true },
  fullName: { type: String, required: true, trim: true, maxlength: 100 },
  email: { type: String, required: true, trim: true, lowercase: true, maxlength: 254 },
  travelerCount: { type: Number, required: true, min: 1, max: 20 },
  message: { type: String, required: true, trim: true, maxlength: 2000 },
  // Staff may change workflow status; public submissions cannot set it.
  status: { type: String, enum: ['new', 'in_progress', 'closed'], default: 'new' }
}, { timestamps: true });

inquirySchema.index({ tripCode: 1, createdAt: -1 });
inquirySchema.index({ status: 1, createdAt: -1 });

module.exports = mongoose.model('inquiries', inquirySchema);
