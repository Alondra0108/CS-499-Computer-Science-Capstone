const mongoose = require('mongoose');
const { toDecimalPrice, toPriceNumber, canonicalPrice, PRICE_MESSAGE } = require('../utils/price');

// Define the trip schema.
const tripSchema = new mongoose.Schema({
  code: { type: String, required: true, index: true },
  name: { type: String, required: true, index: true },
  length: { type: String, required: true },
  start: { type: Date, required: true },
  resort: { type: String, required: true },
  // CS 499, Alondra Paulino Santos, 2026-09-17: exact decimal USD storage.
  perPerson: {
    type: mongoose.Schema.Types.Decimal128,
    required: true,
    set: toDecimalPrice,
    validate: {
      validator(value) {
        try { canonicalPrice(value); return true; } catch { return false; }
      },
      message: PRICE_MESSAGE
    }
  },
  image: { type: String, required: true },
  description: { type: String, required: true }
});

// Keep Decimal128's BSON wrapper out of the API. Clients receive a JSON number.
// The explicit price limit keeps this conversion safe to the nearest cent.
tripSchema.set('toJSON', {
  transform(doc, result) {
    result.perPerson = toPriceNumber(doc.perPerson);
    return result;
  }
});

const Trip = mongoose.model('trips', tripSchema);
module.exports = Trip;
