const express = require('express');
const router = express.Router();

const tripsController = require('../controllers/trips');
const authenticationController = require('../controllers/authentication');
const inquiriesController = require('../controllers/inquiries');
const staffOnly = require('../middleware/staff-only');
const { expressjwt: jwt } = require('express-jwt');

const auth = jwt({
  secret: process.env.JWT_SECRET,
  algorithms: ['HS256']
});

router.post('/register', authenticationController.register);
router.post('/login', authenticationController.login);

// The token identifies the caller; the database role authorizes staff access.
router.get('/inquiries', auth, staffOnly, inquiriesController.list);
router.patch('/inquiries/:id/status', auth, staffOnly, inquiriesController.changeStatus);

// GET all trips and POST a new trip.
router
  .route('/trips')
  .get(tripsController.tripsList)
  .post(auth, staffOnly, tripsController.tripsAddTrip);

// GET one trip by code and update one trip by code.
router
  .route('/trips/:tripCode')
  .get(tripsController.tripsFindByCode)
  .put(auth, staffOnly, tripsController.tripsUpdateTrip)
  .delete(auth, staffOnly, tripsController.tripsDeleteTrip);

module.exports = router;
