/**
 * CS 499 price enhancement for Alondra Paulino Santos | 2026-09-17.
 * Store exact USD decimal values in MongoDB; expose numbers to the UI.
 * Validate instead of silently rounding, coercing blanks, or losing cents.
 */
const mongoose = require('mongoose');
const MAX_PRICE = 999999999.99;
const PRICE_MESSAGE = 'Price must be a number from 0 to 999999999.99 with at most two decimal places.';

function canonicalPrice(value) {
  if (value instanceof mongoose.Types.Decimal128) value = value.toString();
  if (typeof value !== 'number' && typeof value !== 'string') {
    throw new TypeError(PRICE_MESSAGE);
  }
  const text = String(value).trim();
  // Plain dollar amounts only: currency symbols and grouped numbers need review.
  if (!/^\d+(?:\.\d{1,2})?$/.test(text) || Number(text) > MAX_PRICE) {
    throw new TypeError(PRICE_MESSAGE);
  }
  const [whole, fraction = ''] = text.split('.');
  return `${BigInt(whole)}.${fraction.padEnd(2, '0')}`;
}

function toDecimalPrice(value) {
  return mongoose.Types.Decimal128.fromString(canonicalPrice(value));
}

function toPriceNumber(value) {
  return Number(canonicalPrice(value));
}

// The public API contract requires JSON numbers, not numeric-looking strings.
function isApiPrice(value) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return false;
  try { canonicalPrice(value); return true; } catch { return false; }
}

module.exports = { MAX_PRICE, PRICE_MESSAGE, canonicalPrice, toDecimalPrice, toPriceNumber, isApiPrice };
