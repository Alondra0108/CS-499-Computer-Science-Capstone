/**
 * CS 499 | Alondra Paulino Santos | 2026-09-17
 * Shared search contract: validate scalar URL values before building a query.
 * Clients cannot supply database operators, field names or regular expressions.
 */
const { canonicalPrice, toDecimalPrice } = require('./price');
const MAX_SEARCH_LENGTH = 100;
const DEFAULT_SORT = 'departureAsc';
const SORT_OPTIONS = Object.freeze([
  { value: 'departureAsc', label: 'Departure: earliest first', order: { start: 1, _id: 1 } },
  { value: 'departureDesc', label: 'Departure: latest first', order: { start: -1, _id: 1 } },
  { value: 'priceAsc', label: 'Price: low to high', order: { perPerson: 1, _id: 1 } },
  { value: 'priceDesc', label: 'Price: high to low', order: { perPerson: -1, _id: 1 } },
  { value: 'nameAsc', label: 'Trip name: A to Z', order: { name: 1, _id: 1 } }
]);
const FIELDS = ['q', 'minPrice', 'maxPrice', 'startDate', 'endDate', 'sort'];

class SearchValidationError extends Error {
  constructor(errors, criteria) {
    super('Please correct the search fields.');
    this.name = 'SearchValidationError';
    this.errors = errors;
    this.criteria = criteria;
  }
}

/** Parse a real YYYY-MM-DD calendar date, rejecting JavaScript date rollover. */
function parseDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || value.startsWith('0000')) return null;
  const date = new Date(`${value}T00:00:00.000Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value ? date : null;
}

/** Escape metacharacters so user text is a literal substring, not a pattern. */
function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Build a validated MongoDB search from Express query parameters.
 * Empty fields mean no filter; price bounds are inclusive Decimal128 amounts.
 * Date bounds are UTC calendar days. The exclusive next-day end includes the
 * entire selected day without depending on the server's local time zone.
 * @param {Object} input Parsed URL parameters, never a MongoDB query.
 * @returns {{criteria: Object, filter: Object, sort: Object}}
 * @throws {SearchValidationError} Field errors and bounded values for the form.
 */
function buildTripSearch(input = {}) {
  const errors = {};
  const criteria = {};
  for (const name of Object.keys(input)) {
    if (!FIELDS.includes(name)) errors.query = 'Remove unsupported search parameters and try again.';
  }
  for (const name of FIELDS) {
    const raw = input[name];
    if (raw !== undefined && typeof raw !== 'string') errors[name] = 'Provide one value for this field.';
    criteria[name] = typeof raw === 'string' ? raw.trim() : '';
  }
  if (!criteria.sort) criteria.sort = DEFAULT_SORT;
  if (criteria.q.length > MAX_SEARCH_LENGTH) errors.q = `Use no more than ${MAX_SEARCH_LENGTH} characters.`;
  const selectedSort = SORT_OPTIONS.find(option => option.value === criteria.sort);
  if (!selectedSort) errors.sort = 'Choose one of the listed sorting options.';
  const prices = {};
  for (const name of ['minPrice', 'maxPrice']) {
    if (!criteria[name]) continue;
    try { prices[name] = canonicalPrice(criteria[name]); }
    catch { errors[name] = 'Enter a price from 0 to 999999999.99 with at most two decimal places.'; }
  }
  if (prices.minPrice && prices.maxPrice && Number(prices.minPrice) > Number(prices.maxPrice)) {
    errors.maxPrice = 'Maximum price must be at least the minimum price.';
  }
  const dates = {};
  for (const name of ['startDate', 'endDate']) {
    if (!criteria[name]) continue;
    dates[name] = parseDate(criteria[name]);
    if (!dates[name]) errors[name] = 'Enter a real calendar date in YYYY-MM-DD format.';
  }
  if (dates.startDate && dates.endDate && dates.startDate > dates.endDate) errors.endDate = 'End date must be on or after the start date.';
  if (Object.keys(errors).length) {
    for (const name of FIELDS) criteria[name] = criteria[name].slice(0, MAX_SEARCH_LENGTH);
    throw new SearchValidationError(errors, criteria);
  }
  const filter = {};
  if (criteria.q) {
    const literal = new RegExp(escapeRegex(criteria.q), 'i');
    filter.$or = [{ name: literal }, { resort: literal }];
  }
  if (prices.minPrice || prices.maxPrice) {
    filter.perPerson = {};
    if (prices.minPrice) filter.perPerson.$gte = toDecimalPrice(prices.minPrice);
    if (prices.maxPrice) filter.perPerson.$lte = toDecimalPrice(prices.maxPrice);
  }
  if (dates.startDate || dates.endDate) {
    filter.start = {};
    if (dates.startDate) filter.start.$gte = dates.startDate;
    if (dates.endDate) {
      const nextDay = new Date(dates.endDate);
      nextDay.setUTCDate(nextDay.getUTCDate() + 1);
      filter.start.$lt = nextDay;
    }
  }
  // Top-level filters are ANDed; only trip-name/resort matching is ORed.
  // The unique ID breaks ties to keep repeated requests in a stable order.
  return { criteria, filter, sort: { ...selectedSort.order } };
}

module.exports = { buildTripSearch, SearchValidationError, SORT_OPTIONS, DEFAULT_SORT, MAX_SEARCH_LENGTH };
