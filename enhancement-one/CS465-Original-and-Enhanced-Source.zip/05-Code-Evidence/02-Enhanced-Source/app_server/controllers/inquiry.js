/**
 * Trip inquiries | CS 499, Alondra Paulino Santos | 2026-09-17.
 * Public form: show a real trip, validate and save a question, then redirect
 * so refreshing the confirmation page cannot submit the message twice.
 */
const jwt = require('jsonwebtoken');
const Trip = require('../../app_api/models/travlr');
const Inquiry = require('../../app_api/models/inquiry');
const { toPriceNumber } = require('../../app_api/utils/price');
const { formatPrice } = require('../utils/price-display');
const { validateInquiry } = require('../utils/inquiry-validation');

const emptyValues = { fullName: '', email: '', travelerCount: '', message: '' };
const safeTripCode = code => /^[A-Za-z0-9_-]{1,40}$/.test(code);
const inquiryPath = code => `/travel/${encodeURIComponent(code)}/inquiry`;

function formToken(tripCode) {
  return jwt.sign({ purpose: 'trip-inquiry', tripCode }, process.env.JWT_SECRET, { expiresIn: '30m' });
}

function validToken(token, tripCode) {
  if (typeof token !== 'string') return false;
  try {
    const claims = jwt.verify(token, process.env.JWT_SECRET, { algorithms: ['HS256'] });
    return claims.purpose === 'trip-inquiry' && claims.tripCode === tripCode;
  } catch { return false; }
}

/** A short-lived receipt keeps the success page tied to a completed save. */
function receiptToken(inquiry) {
  return jwt.sign({ purpose: 'inquiry-receipt', tripCode: inquiry.tripCode, inquiryId: String(inquiry._id) }, process.env.JWT_SECRET, { expiresIn: '1h' });
}

function receiptClaims(token, tripCode) {
  if (typeof token !== 'string') return false;
  try {
    const claims = jwt.verify(token, process.env.JWT_SECRET, { algorithms: ['HS256'] });
    return claims.purpose === 'inquiry-receipt' && claims.tripCode === tripCode && /^[a-f0-9]{24}$/.test(claims.inquiryId) ? claims : null;
  } catch { return null; }
}

async function findTrip(code) {
  if (!safeTripCode(code)) return null;
  return Trip.findOne({ code }).maxTimeMS(3000).exec();
}

function formModel(trip, values = emptyValues, errors = {}, message = '') {
  return {
    title: `Ask About ${trip.name} - Travlr Getaways`,
    trip: { code: trip.code, name: trip.name, resort: trip.resort, priceDisplay: formatPrice(toPriceNumber(trip.perPerson)) },
    values, errors, message, token: formToken(trip.code)
  };
}

/** A missing trip is a normal 404; database failures get a generic 503. */
async function showForm(req, res) {
  try {
    const trip = await findTrip(req.params.tripCode);
    if (!trip) return res.status(404).render('inquiry-unavailable', { title: 'Trip Not Found', message: 'This trip is not available.' });
    return res.status(200).render('inquiry', formModel(trip));
  } catch (error) {
    console.error('[inquiry] Trip lookup failed', { name: error.name });
    return res.status(503).render('inquiry-unavailable', { title: 'Unable to Load Trip', message: 'Unable to load this trip. Please try again.' });
  }
}

async function submitForm(req, res) {
  const code = req.params.tripCode;
  if (!safeTripCode(code)) return res.status(404).render('inquiry-unavailable', { title: 'Trip Not Found', message: 'This trip is not available.' });
  try {
    const trip = await findTrip(code);
    if (!trip) return res.status(404).render('inquiry-unavailable', { title: 'Trip Not Found', message: 'This trip is not available.' });
    if (!validToken(req.body?.formToken, code)) {
      const { values } = validateInquiry(req.body);
      return res.status(403).render('inquiry', formModel(trip, values, {}, 'Your form expired. Please try again.'));
    }
    const { values, errors } = validateInquiry(req.body);
    if (Object.keys(errors).length) {
      return res.status(400).render('inquiry', formModel(trip, values, errors, 'Please correct the fields below.'));
    }
    // The trip association and workflow status come from trusted server data.
    const inquiry = await Inquiry.create({
      tripCode: trip.code,
      tripName: trip.name,
      fullName: values.fullName,
      email: values.email,
      travelerCount: Number(values.travelerCount),
      message: values.message
    });
    return res.redirect(303, `${inquiryPath(code)}/sent?receipt=${encodeURIComponent(receiptToken(inquiry))}`);
  } catch (error) {
    console.error('[inquiry] Submission failed', { name: error.name });
    return res.status(503).render('inquiry-unavailable', { title: 'Unable to Send Inquiry', message: 'Unable to send your inquiry. Please try again.' });
  }
}

async function confirmation(req, res) {
  const claims = receiptClaims(req.query.receipt, req.params.tripCode);
  if (!claims) {
    return res.status(404).render('inquiry-unavailable', { title: 'Confirmation Unavailable', message: 'This confirmation link is unavailable.' });
  }
  try {
    const inquiry = await Inquiry.findOne({ _id: claims.inquiryId, tripCode: req.params.tripCode })
      .select('tripName referenceNumber').maxTimeMS(3000).lean().exec();
    if (!inquiry) return res.status(404).render('inquiry-unavailable', { title: 'Confirmation Unavailable', message: 'This confirmation link is unavailable.' });
    return res.status(200).render('inquiry-sent', {
      title: 'Inquiry Received - Travlr Getaways',
      tripName: inquiry.tripName,
      referenceNumber: inquiry.referenceNumber
    });
  } catch (error) {
    console.error('[inquiry] Confirmation lookup failed', { name: error.name });
    return res.status(503).render('inquiry-unavailable', { title: 'Unable to Load Trip', message: 'Unable to load this trip. Please try again.' });
  }
}

module.exports = { showForm, submitForm, confirmation };
