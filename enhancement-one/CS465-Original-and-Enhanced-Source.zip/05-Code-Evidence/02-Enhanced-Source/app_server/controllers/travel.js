/**
 * Public trip browsing | CS 499, Alondra Paulino Santos | 2026-09-17.
 * Preserve validated GET form values, call the API, and format display values.
 * Database access stays in the API; this controller owns page presentation.
 */
const { formatPrice } = require('../utils/price-display');
const { safeTripDescription } = require('../utils/trip-description');
const { buildTripSearch, SearchValidationError, SORT_OPTIONS } = require('../../app_api/utils/trip-search');
const dateFormat = new Intl.DateTimeFormat('en-US', { dateStyle: 'medium', timeZone: 'UTC' });

/** Build only the form/display fields needed by the Handlebars template. */
function viewModel(criteria, errors = {}) {
    return {
        title: 'Find a Trip - Travlr Getaways', criteria, errors, trips: [],
        sortOptions: SORT_OPTIONS.map(({ value, label }) => ({ value, label, selected: criteria.sort === value }))
    };
}

/**
 * GET /travel: 400 renders field errors; 503 renders a safe retrieval error.
 * Successful empty results remain 200 and offer a way to clear the filters.
 */
const travel = async (req, res) => {
    let criteria;
    try {
        ({ criteria } = buildTripSearch(req.query));
    } catch (error) {
        if (!(error instanceof SearchValidationError)) throw error;
        return res.status(400).render('travel', {
            ...viewModel(error.criteria, error.errors), errorMessage: error.message
        });
    }
    const model = viewModel(criteria);
    try {
        // Trusted server configuration only: never use a user-supplied host/URL.
        const endpoint = new URL(process.env.TRIPS_API_URL || `http://127.0.0.1:${process.env.PORT || 3000}/api/trips`);
        for (const [key, value] of Object.entries(criteria)) {
            if (value) endpoint.searchParams.set(key, value);
        }
        const response = await fetch(endpoint, {
            headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(5000)
        });
        if (!response.ok) throw new Error(`Trip API status ${response.status}`);
        const trips = await response.json();
        if (!Array.isArray(trips)) throw new Error('Unexpected trip response format');
        model.trips = trips.map(trip => ({
            ...trip, priceDisplay: formatPrice(trip.perPerson),
            // The template intentionally renders only this sanitized HTML.
            description: safeTripDescription(trip.description),
            // Use the same UTC calendar-day convention as the date filters.
            departureDisplay: dateFormat.format(new Date(trip.start))
        }));
        model.resultCount = trips.length;
        model.resultLabel = trips.length === 1 ? 'trip found' : 'trips found';
        model.noResults = trips.length === 0;
        return res.status(200).render('travel', model);
    } catch (error) {
        console.error('[travel-page] Trip retrieval failed', { name: error.name });
        return res.status(503).render('travel', {
            ...model, errorMessage: 'Unable to retrieve trips. Please try again.'
        });
    }
};

module.exports = {
    travel
};
