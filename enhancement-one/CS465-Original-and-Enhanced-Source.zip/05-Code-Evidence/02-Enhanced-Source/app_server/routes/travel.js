var express = require('express');
var router = express.Router();

const ctrlTravel = require('../controllers/travel');
const ctrlInquiry = require('../controllers/inquiry');

/* GET travel page */
router.get('/', ctrlTravel.travel);

// Ask about a specific trip. The POST saves the question, not a booking.
router.get('/:tripCode/inquiry', ctrlInquiry.showForm);
router.post('/:tripCode/inquiry', ctrlInquiry.submitForm);
router.get('/:tripCode/inquiry/sent', ctrlInquiry.confirmation);

module.exports = router;
