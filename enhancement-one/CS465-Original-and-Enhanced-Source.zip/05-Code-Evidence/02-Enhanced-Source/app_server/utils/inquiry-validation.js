/**
 * CS 499 | Alondra Paulino Santos | 2026-09-17
 * Validate form data on the server. Browser attributes help users but can be
 * bypassed, so only these normalized values are saved to the database.
 */
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validateInquiry(body = {}) {
  const errors = {};
  const values = {};
  for (const field of ['fullName', 'email', 'message']) {
    const input = body[field];
    if (typeof input !== 'string') errors[field] = 'Enter one value for this field.';
    values[field] = typeof input === 'string' ? input.trim() : '';
  }
  if (!errors.fullName && (values.fullName.length < 2 || values.fullName.length > 100 || /[\x00-\x1f\x7f]/.test(values.fullName))) {
    errors.fullName = 'Enter a name between 2 and 100 characters.';
  }
  if (!errors.email && (values.email.length > 254 || !EMAIL_PATTERN.test(values.email))) {
    errors.email = 'Enter a valid email address.';
  }
  const travelerInput = body.travelerCount;
  if (typeof travelerInput !== 'string' || !/^(?:[1-9]|1\d|20)$/.test(travelerInput.trim())) {
    errors.travelerCount = 'Enter a whole number of travelers from 1 to 20.';
  }
  values.travelerCount = typeof travelerInput === 'string' ? travelerInput.trim().slice(0, 2) : '';
  if (!errors.message && (values.message.length < 10 || values.message.length > 2000 || /[\x00-\x08\x0b-\x1f\x7f]/.test(values.message))) {
    errors.message = 'Enter a message between 10 and 2000 characters.';
  }
  // Bound any reflected values, including invalid submissions, before display.
  return {
    values: { fullName: values.fullName.slice(0, 100), email: values.email.slice(0, 254), travelerCount: values.travelerCount, message: values.message.slice(0, 2000) },
    errors
  };
}

module.exports = { validateInquiry };
