/** CS 499 | Alondra Paulino Santos | 2026-09-17: format numeric USD for display. */
const { isApiPrice } = require('../../app_api/utils/price');
const currency = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' });
function formatPrice(value) {
  return isApiPrice(value) ? currency.format(value) : 'Price unavailable';
}
module.exports = { formatPrice };
