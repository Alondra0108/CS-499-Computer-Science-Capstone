/**
 * Trip description presentation | CS 499, Alondra Paulino Santos | 2026-09-19.
 * Legacy descriptions contain paragraph markup. Sanitize that stored HTML at
 * the presentation boundary so formatting is retained without trusting data
 * merely because it came from the database or administrator application.
 */
const sanitizeHtml = require('sanitize-html');

function safeTripDescription(value) {
  if (typeof value !== 'string') return '';
  return sanitizeHtml(value, {
    allowedTags: ['p'],
    allowedAttributes: {},
    disallowedTagsMode: 'discard'
  });
}

module.exports = { safeTripDescription };
