# Administrator inquiry management

Alondra Paulino Santos — CS 499, Software Engineering and Design  
Implemented: September 17, 2026

## Purpose

The customer inquiry form now has a staff workflow. Authorized staff can open
the Angular admin application's **Inquiries** page, review questions, filter
them by status, move through pages of 20, and change each status to New,
In progress, or Closed. A status changes only after **Save status** is pressed.
Each item includes its customer-facing reference number and traveler count so
staff can identify the request and understand the requested party size.
The inbox does not send email, reserve travel, or delete customer inquiries.

## How the code is organized

- `app_api/models/inquiry.js` holds the saved question, trip link, timestamps,
  and status. It includes indexes for the staff list and trip lookup.
- `app_api/controllers/inquiries.js` supplies a paginated, filtered list and
  validates status updates. It accepts only an explicit status field, preventing
  a request from changing a customer's name, email, or message.
- `app_api/middleware/staff-only.js` checks the user's **current role in the
  database** after JWT authentication. Removing staff access takes effect
  immediately, even when a previously issued token has not expired.
- `app_api/models/user.js` gives public registrations the customer role.
  The token includes a role for admin navigation, but the token claim alone
  never grants access to an API. Existing users without a role are customers.
- The trip create, edit, and delete APIs now use the same staff check. The
  previous token-only rule allowed any registered user to change trips.
- `app_admin/src/app/inquiry-list/` contains the inbox screen; its service
  and model are in `app_admin/src/app/services/inquiry-data.ts` and
  `app_admin/src/app/models/inquiry.ts`. Angular escapes inquiry text, and
  `white-space: pre-wrap` preserves line breaks without interpreting HTML.
- The inbox route, navigation link, trip editing buttons, and login redirect
  follow the staff role. Server checks remain authoritative.

## Granting access to the right account

Staff access is intentionally not assigned by public registration. First,
register or confirm the account to use in the enhanced database. Then run the
provisioning script from the enhanced project folder with that exact email:

```sh
npm run grant:staff -- person@example.com
npm run grant:staff -- person@example.com --apply
```

The first command is a dry run. The second grants staff access only to that
existing account in `travlr_capstone` (or the explicitly configured `DB_NAME`).
The script refuses the original `travlr` database. Log out and sign in again
after the role changes so the Angular menu receives a fresh role claim. The
API always checks the database role, including while an old token remains.

The enhanced database contained one existing account, `admin@travlr.com`.
That account was granted staff access for this implementation. No account in
the original CS 465 database was changed. If another account should become
staff later, use the dry run and apply commands above for its exact email.

## Verification

```sh
npm test
npm run test:staff
npm run test:inquiry
npm run test:search
npm run test:integration
cd app_admin
NG_BUILD_MAX_WORKERS=1 npm test -- --watch=false
NG_BUILD_MAX_WORKERS=1 npm run build -- --progress=false
```

The staff integration test uses a uniquely named disposable database and
checks guest rejection, customer rejection, staff access, status filtering,
pagination, invalid updates, public registration, and immediate revocation.
The inquiry and price integration checks continue to pass with staff-only
trip writes. The Angular unit suite and production build pass. The build
reports a nonblocking initial-bundle size warning; this enhancement does not
claim to solve the inherited overall bundle-size issue.

## Remaining work for the capstone

This completes the three planned customer and staff features in the CS 465
enhancement. The original CS 465 folder and database remain untouched. Before
submitting the milestone, review the screen while signed in, update the
software design document and narrative,
and package the original and enhanced artifacts according to the rubric.
