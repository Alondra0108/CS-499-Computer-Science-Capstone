# CS 465 Capstone Enhancement: Final Implementation Audit

**Author:** Alondra Paulino Santos  
**Reviewed:** September 19, 2026

## Scope and alignment

The enhanced copy preserves the original CS 465 trip administration workflow:
staff authentication, trip listing, and authenticated create, update, and delete
operations. It adds the three approved software-engineering enhancements:

1. Public trip search, combined filters, and allowlisted sorting.
2. A trip-specific customer inquiry form with traveler count and a customer-facing
   reference number.
3. A staff-only inquiry inbox with status filtering, pagination, and explicit
   status updates.

Trip prices were also migrated from formatted strings to MongoDB `Decimal128` so
database comparisons and sorting use numeric values without losing cents.

## Design and code-quality review

- Routes, controllers, utilities, Mongoose models, Angular services, and UI
  components have separate responsibilities.
- Enhanced files use short headers and decision-focused comments. Comments explain
  validation, authorization, numeric storage, safe rendering, and workflow choices
  without repeating self-explanatory statements.
- API inputs use allowlists, bounded values, Mongoose validation, and generic
  failure messages. Raw database errors are logged as limited metadata instead of
  being returned to a browser.
- Public registration cannot assign the `staff` role. Protected endpoints validate
  the JWT and then check the user's current database role, so revoking staff access
  takes effect even when an older token still exists.
- The inquiry POST verifies a short-lived token and a real trip, applies server-side
  field validation, saves trusted server-owned fields, and uses a `303` redirect to
  prevent accidental resubmission on refresh.
- Legacy trip descriptions retain their paragraph formatting but are sanitized
  before unescaped rendering. Executable tags and attributes are removed.
- Maintained production dependencies were updated and `npm audit --omit=dev`
  reports zero known vulnerabilities.

## Verification completed

- Backend unit tests: **15 passed**.
- Price and original trip CRUD integration test: **passed**.
- Search/filter integration test: **passed**.
- Public inquiry and receipt integration test: **passed**.
- Staff authorization and inquiry-management integration test: **passed**.
- Angular component/service tests: **16 passed across 8 test files**.
- Angular TypeScript compilation (`tsc --noEmit`): **passed**.

The integration scripts create randomly named disposable test databases and remove
them afterward. They do not write to the original CS 465 database or the enhanced
application database.
