# CS 499 - Numeric trip prices

Project: CS465-Capstone-Enhanced  
Student: Alondra Paulino Santos  
Implementation date: September 17, 2026

## What changed

Previously, `perPerson` was stored as text. The enhanced model stores a MongoDB
**Decimal128 number**, which preserves decimal dollar/cents values and supports
numeric database comparisons. The API returns an ordinary JSON number; Angular's
trip models and add/edit forms now use numbers as well. No booking, payment,
search, inquiry or staff-management features were added in this step.

Price rules are enforced in both the API and the Angular forms:

- Required, finite numeric value between $0 and $999,999,999.99.
- At most two decimal places; invalid precision is rejected, not rounded.
- Zero is allowed. Blank values, negative amounts, booleans, numeric strings in
  API requests, and currency symbols are rejected.
- The upper limit is an explicit application guardrail that keeps JSON-number
  conversion reliable to the nearest cent. It is not a MongoDB storage limit.

The public travel page now displays prices with a dollar sign and two decimal
places. The Angular trip cards retain their existing USD currency formatting.
Formatting does not change the stored amount. A JSON number such as `799` is
displayed as `$799.00`; JSON numbers do not preserve trailing zeros.

MongoDB tools may show `{"$numberDecimal":"799.00"}`. That is Extended JSON's
representation of a BSON decimal number, not a return to String storage.
Do future monetary calculations in decimal arithmetic or integer cents rather
than assuming JavaScript floating-point arithmetic is exact.

## Database isolation and conversion

- Original project database: `travlr` (not modified).
- Enhanced project database: `travlr_capstone` (the enhanced app's new default).
- All four source trips were copied; all four prices were converted and verified:
  $799.00, $1,199.00, $1,999.00 and $3,499.00.
- Existing local accounts and indexes were copied so the existing login works.
  Changes in the enhanced database do not change the original accounts or trips.
- An original trip-data backup is in `backups/original-trip-prices-*.json`.
  Backups are excluded from Git. Do not publish database credentials or accounts.

`DB_NAME` can override the enhanced database name. Do not point this enhanced
application at the original `travlr` database. Keep the two servers from running
on the same port simultaneously.

The conversion has already been performed on this computer. **Do not rerun the
seed script to migrate prices:** it deletes existing trips before inserting the
three sample records, which would lose the fourth trip.

For a fresh installation only, with the original local database present:

```sh
npm run prepare:prices
npm run prepare:prices -- --apply
```

The first command is a dry run. The second validates all source prices, saves a
trip-data backup, copies trips/accounts/indexes, and verifies the stored amounts.
It refuses an existing/nonempty target database or a target named `travlr`.
Malformed legacy amounts stop conversion before any database writes; they are not
guessed or rounded. If copying is interrupted, inspect the partial target rather
than rerunning a seed or deleting data without review.

To return to the original application, run the untouched original project, which
still uses its original database. Do not overwrite either copy as a rollback.

## Run the enhanced application

From `CS465-Capstone-Enhanced`, with local MongoDB running:

```sh
npm start
```

In a second terminal, from `CS465-Capstone-Enhanced/app_admin`:

```sh
npm start
```

The public travel page is at `http://localhost:3000/travel`; Angular is at
`http://localhost:4200`. Existing local credentials can be used in the enhanced
copy. This step does not add staff roles or change the authentication design.

## Verification completed

| Check | Result |
| --- | --- |
| Server price/model/serialization/display tests | 6 passed |
| Angular tests, including typed add/edit prices and currency display | 14 passed |
| Local API + MongoDB integration smoke test | Passed |
| Production Angular build | Passed; nonblocking initial-bundle size warning |

The integration test creates a uniquely named temporary test database and removes
only that test database afterward. It verifies create, retrieve, edit and delete;
rejection of invalid prices; BSON Decimal128 storage; zero-dollar values; numeric
sorting/filtering; and the public page's currency display. It does not write test
records into `travlr` or `travlr_capstone`.

Re-run from the enhanced project root:

```sh
npm test
npm run test:integration
```

From `app_admin`:

```sh
npm test -- --watch=false
npm run build
```

The integration test needs a local MongoDB server. Tests of the public page use
an isolated local API connection. A full manual browser walkthrough remains useful
when implementing the upcoming search and inquiry features.

## Main files to study

- `app_api/utils/price.js`: validation, exact decimal conversion, API numeric values.
- `app_api/models/travlr.js`: Decimal128 field and JSON serialization.
- `app_api/controllers/trips.js`: server-side create/update price checks.
- `app_admin/src/app/validators/price.ts`: matching form rules.
- Add/edit forms and both TypeScript trip models: numeric controls and types.
- `app_server/utils/price-display.js`, travel controller/template: USD display.
- `scripts/prepare-price-database.js`: safe, one-time copy/conversion.

Design reference: MongoDB's [monetary-data modeling guidance](https://www.mongodb.com/docs/v8.0/tutorial/model-monetary-data/)
describes Decimal128 as an exact decimal representation for monetary values.
