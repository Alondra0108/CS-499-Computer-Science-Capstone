# Trip inquiry form

Alondra Paulino Santos — CS 499, Software Engineering and Design  
Implemented: September 17, 2026

## What changed

Each trip on `/travel` now links to `/travel/:tripCode/inquiry`. The page shows
the selected trip and asks for a customer's name, email address, number of
travelers, and question.
The form is an inquiry only; it does not reserve a trip or collect payment.

The server checks that the trip exists, validates the form, saves the inquiry
in the enhanced project's MongoDB database, and redirects to a confirmation
page with a short-lived signed receipt. A page refresh after submission
therefore does not post the question again, and opening the confirmation URL
without a receipt does not falsely report a successful submission. The
confirmation displays a unique, customer-friendly reference number and says
the question was saved for review; the project
does not send an email or claim that staff already answered it.

## Code and design decisions

- `app_server/views/travel.hbs` adds the link from each result.
- `app_server/views/inquiry.hbs`, `inquiry-sent.hbs`, and
  `inquiry-unavailable.hbs` show the form, confirmation and safe errors.
- `app_server/controllers/inquiry.js` handles GET and POST, looks up the trip,
  signs a 30-minute form token bound to its code, and redirects after a save.
  The token prevents a different website from submitting the browser form
  without first obtaining a valid token for the selected trip. It is not an
  anti-spam or rate-limiting system. A one-hour signed receipt protects the
  confirmation page from being opened as if a save had occurred.
- `app_server/utils/inquiry-validation.js` trims fields and validates them on
  the server. Name is 2–100 characters, email at most 254 with a basic email
  shape, traveler count a whole number from 1–20, and message 10–2000
  characters. The browser constraints are guidance;
  the server decides what is accepted. Invalid fields are shown by name, and
  bounded values remain in the form so the customer can correct them.
- `app_api/models/inquiry.js` stores a generated reference number, trip code,
  a snapshot of the trip name, normalized contact information, traveler count,
  message, creation time, and status `new`. Customers cannot choose the
  reference number or set a workflow status in the form.
- The reference follows `INQ-YYYYMMDD-XXXXXXXX`. It uses cryptographically
  random bytes and a unique database index, is separate from MongoDB's internal
  identifier, and is shown only after the signed receipt is verified against a
  saved inquiry.
- The templates escape user-provided values. Failed lookups or writes show
  generic customer-facing messages, without raw database errors.
- The navigation links are root-relative so they work from the nested inquiry
  URL. The CSS stays scoped to the travel and inquiry pages.

This public form writes to the enhanced database (`travlr_capstone` by default).
It does not modify the original CS 465 application or its database. Staff
inquiry management, authorization, notifications, and production spam controls
remain separate enhancements.

## How to verify

With local MongoDB available, run these commands in the enhanced project:

```sh
npm test
npm run test:inquiry
npm run test:search
npm run test:integration
npm start
```

Then open `http://localhost:3000/travel`, choose **Ask about this trip**, and
review the form. Submitting a real question creates a record in the enhanced
database; the automated inquiry test instead creates and removes a uniquely
named temporary database. Its checks cover the linked form, price display,
invalid fields, invalid traveler counts, invalid token, unknown trip, saved
values, generated reference, default status, and confirmation redirect.
