# Trip search and filters

Alondra Paulino Santos — CS 499, Software Engineering and Design  
Implemented and verified: September 17, 2026

## Purpose and scope

Customers previously had to browse every trip to find a suitable destination.
The public `/travel` page now searches trip names or resorts, combines minimum
and maximum prices with departure-date filters, and sorts the matching trips.
The existing page theme and API array response are preserved.

This enhancement does not implement the planned inquiry form or administrator
inquiry management. It does not modify the original CS 465 project or its database.

## How the implementation works

1. The customer submits the labeled GET form. Its URL can be bookmarked.
2. A shared server-side validator checks the search fields. Invalid fields return
   HTTP 400 with an explanation; the form retains bounded input values.
3. The API builds its own MongoDB query from the validated values. Name/resort
   matching is OR; the active text, price and date filters combine with AND.
4. MongoDB filters and sorts before returning records. Prices use the exact
   Decimal128 storage introduced in the price enhancement, not string sorting.
5. The public controller formats prices and departure dates and renders results.
   No matches returns HTTP 200 with a clear-filters option, not a database error.
6. Retrieval failures return HTTP 503 with a generic customer-facing message.

## Input contract and design decisions

- `q`: optional literal substring of trip name or resort, case-insensitive,
  trimmed, maximum 100 characters. Regex metacharacters are escaped.
- `minPrice`, `maxPrice`: optional inclusive USD bounds from 0 to 999999999.99,
  at most two decimal places. Zero is a valid bound. Minimum cannot exceed maximum.
- `startDate`, `endDate`: optional real calendar dates in YYYY-MM-DD format.
  Both selected days are included. The database query uses UTC midnight for the
  start and excludes midnight immediately after the end day. This includes late
  departures on the end day and avoids dependence on the server's local time zone.
- `sort`: `departureAsc` (default), `departureDesc`, `priceAsc`, `priceDesc`, or
  `nameAsc`. A unique `_id` tie breaker makes identical primary values stable.
- Unknown parameters, repeated values, arrays, objects and unlisted sort choices
  are rejected. Clients cannot select arbitrary database fields or operators.
- Existing past-dated sample trips remain visible unless the customer filters
  them out. The enhancement does not silently change the sample data.
- The public controller uses a trusted server-configured API URL, never a host
  provided by a customer. Its request timeout is five seconds; the MongoDB query
  has a three-second execution limit. These are distinct limits, not a guarantee
  that every type of database connection failure ends within three seconds.
- Handlebars escapes search values. Validation errors are associated with their
  labeled fields, and controls have visible keyboard focus styles.

## Reading order for the code

1. `app_api/utils/trip-search.js`: shared validation, query construction and sorts.
2. `app_api/controllers/trips.js`: list endpoint, database query and response status.
3. `app_server/controllers/travel.js`: retained form values, API call and formatting.
4. `app_server/views/travel.hbs`: search form, field errors and trip results.
5. `public/css/trip-search.css`: styles scoped to the search feature.

Comments document intent, boundaries and non-obvious decisions rather than
repeating every statement. Price conversion remains documented separately in
`docs/PRICE_ENHANCEMENT.md`.

## Verification

Run from the enhanced project folder with local MongoDB running:

```sh
npm test
npm run test:integration
npm run test:search
npm start
```

Open `http://localhost:3000/travel`. A different API location can be configured
on the server with `TRIPS_API_URL`; otherwise the page calls the local API on
`PORT` (default 3000).

Verified results:

- All 11 unit tests passed, including five search-contract tests.
- The existing price integration checks passed after the search changes.
- Search integration checks passed for combined filters, case-insensitive literal
  text, numeric ordering, zero-price bounds, inclusive end dates, rejected invalid
  input, retained form values, empty results, HTML escaping and safe failure messages.
- Integration scripts use uniquely named temporary databases and remove only
  those databases after the checks. They do not write application data.
- Browser verification: searching `reef` with maximum price `1000` displayed
  one matching trip, Gale Reef Updated at $799.00, and retained both filters.
- The search form was visually checked against the existing desktop page design.

## Limits and future work

The current small catalog returns all matching records without pagination.
Unanchored case-insensitive substring searches may scan a large collection;
this work does not claim an indexed search-performance improvement. A larger
catalog would require measured query plans, suitable indexing/search technology
and pagination. The inherited fixed-width overall site layout is unchanged.
Existing trip-detail links and HTML descriptions are outside this feature's scope.
