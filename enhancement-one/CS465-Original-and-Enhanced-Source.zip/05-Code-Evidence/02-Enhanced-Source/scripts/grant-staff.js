/**
 * One-time staff provisioning for the enhanced CS 465 database.
 * Dry run by default. --apply updates only an existing, exact-email account.
 */
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../app_api/models/user');

async function main() {
  const email = process.argv.find(arg => arg.includes('@'))?.trim().toLowerCase();
  const apply = process.argv.includes('--apply');
  const databaseName = process.env.DB_NAME || 'travlr_capstone';
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Provide the exact existing account email.');
  if (databaseName === 'travlr') throw new Error('Refusing to change the original CS 465 database.');
  await mongoose.connect(`mongodb://${process.env.DB_HOST || '127.0.0.1'}/${databaseName}`);
  const user = await User.findOne({ email }).select('email role').exec();
  if (!user) throw new Error('No account with that email exists in the enhanced database.');
  if (!apply) {
    console.log(`Dry run: ${email} in ${databaseName} has role ${user.role || 'customer'}. Rerun with --apply to grant staff access.`);
    return;
  }
  await User.updateOne({ _id: user._id }, { $set: { role: 'staff' } });
  console.log(`Staff access granted to ${email} in ${databaseName}. Sign in again to refresh the admin navigation.`);
}

main().catch(error => { console.error(error.message); process.exitCode = 1; }).finally(() => mongoose.disconnect());
