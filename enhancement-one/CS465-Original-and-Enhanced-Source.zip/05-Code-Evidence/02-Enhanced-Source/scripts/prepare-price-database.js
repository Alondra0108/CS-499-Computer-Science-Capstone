/**
 * CS 499 | Alondra Paulino Santos | 2026-09-17.
 * Copy the original local trips/users into a NEW capstone database. Convert only
 * the copied prices to Decimal128. Never write to the source or overwrite a target.
 * Dry-run by default; --apply makes the reviewed copy after a trip-data backup.
 */
require('dotenv').config({ quiet: true });
const fs = require('node:fs/promises');
const path = require('node:path');
const mongoose = require('mongoose');
const { toDecimalPrice, canonicalPrice } = require('../app_api/utils/price');
const { BSON } = mongoose.mongo;

async function prepare({ apply = false, sourceName = 'travlr', targetName = process.env.DB_NAME || 'travlr_capstone' } = {}) {
  if (sourceName === targetName || targetName === 'travlr') {
    throw new Error('The enhanced database must be different from the original travlr database.');
  }
  const client = new mongoose.mongo.MongoClient(`mongodb://${process.env.DB_HOST || '127.0.0.1'}`, { serverSelectionTimeoutMS: 5000 });
  try {
    await client.connect();
    const source = client.db(sourceName);
    const target = client.db(targetName);
    if ((await target.listCollections().toArray()).length) {
      throw new Error('Target database is not empty. No changes made; do not overwrite an existing enhancement.');
    }
    const sourceCollections = (await source.listCollections().toArray()).map(c => c.name);
    if (!sourceCollections.includes('trips')) throw new Error('Source trips collection not found.');
    const trips = await source.collection('trips').find({}).toArray();
    if (!trips.length) throw new Error('Source has no trips. Confirm the source database before proceeding.');
    // Validate every amount before any database write. Fail rather than guess.
    const converted = trips.map(trip => {
      try { return { ...trip, perPerson: toDecimalPrice(trip.perPerson) }; }
      catch { throw new Error(`Trip ${trip.code || trip._id} has an invalid price; fix/review it before migration.`); }
    });
    const names = ['trips', 'users'].filter(name => sourceCollections.includes(name));
    const users = names.includes('users') ? await source.collection('users').find({}).toArray() : [];
    const indexes = {};
    for (const name of names) indexes[name] = await source.collection(name).indexes();
    console.log(`Validated ${trips.length} trip prices. ${apply ? 'Copying' : 'Dry run only:'} ${sourceName} -> ${targetName}.`);
    if (!apply) return;

    const backupDir = path.join(__dirname, '../backups');
    await fs.mkdir(backupDir, { recursive: true, mode: 0o700 });
    const backupPath = path.join(backupDir, `original-trip-prices-${Date.now()}.json`);
    await fs.writeFile(backupPath, BSON.EJSON.stringify(trips, { relaxed: false }), { flag: 'wx', mode: 0o600 });
    // Original account hashes are copied unchanged so existing local logins work.
    // No account details, password hashes or connection credentials are logged.
    for (const name of names) {
      await target.createCollection(name);
      const records = name === 'trips' ? converted : users;
      if (records.length) await target.collection(name).insertMany(records, { ordered: true });
      for (const index of indexes[name]) {
        if (index.name === '_id_') continue;
        const { key, v, ns, ...options } = index;
        await target.collection(name).createIndex(key, options);
      }
    }
    const saved = await target.collection('trips').find({}).toArray();
    if (saved.length !== trips.length || saved.some((trip) => {
      const original = trips.find(t => t._id.equals(trip._id));
      return !(trip.perPerson instanceof mongoose.Types.Decimal128) || canonicalPrice(trip.perPerson) !== canonicalPrice(original.perPerson);
    })) throw new Error('Post-copy verification failed. Original database remains unchanged.');
    console.log(`Verified ${saved.length} decimal prices. Original database unchanged. Backup: ${backupPath}`);
  } finally {
    await client.close();
  }
}

if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.some(arg => arg !== '--apply')) {
    console.error('Usage: npm run prepare:prices -- [--apply]'); process.exitCode = 1;
  } else prepare({ apply: args.includes('--apply') }).catch(error => {
    console.error(error.message); process.exitCode = 1;
  });
}
module.exports = { prepare };
