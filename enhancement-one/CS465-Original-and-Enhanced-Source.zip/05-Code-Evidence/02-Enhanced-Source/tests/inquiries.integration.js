/** Staff API checks use a disposable database, never the user's application data. */
const assert = require('node:assert/strict');
const { randomUUID, randomBytes } = require('node:crypto');
const { once } = require('node:events');
const mongoose = require('mongoose');
const testDatabase = `cs465_staff_test_${randomUUID().replaceAll('-', '')}`;
process.env.DB_NAME = testDatabase;
process.env.DB_HOST = '127.0.0.1:27017';
process.env.JWT_SECRET = randomBytes(32).toString('hex');
let server;

async function run() {
  const connected = once(mongoose.connection, 'connected');
  const app = require('../app');
  await connected;
  const User = require('../app_api/models/user');
  const Inquiry = require('../app_api/models/inquiry');
  const staff = new User({ name: 'Staff', email: 'staff@example.test', role: 'staff' });
  staff.setPassword('test-only-password');
  await staff.save();
  const customer = new User({ name: 'Customer', email: 'customer@example.test' });
  customer.setPassword('test-only-password');
  await customer.save();
  const inquiries = await Inquiry.create(Array.from({ length: 21 }, (_, i) => ({
    tripCode: 'TEST', tripName: 'Test Trip', fullName: `Customer ${i}`,
    email: `customer${i}@example.test`, travelerCount: (i % 4) + 1,
    message: 'Please tell me about this trip.'
  })));
  server = app.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const base = `http://127.0.0.1:${server.address().port}`;
  const request = (method, path, token, body) => fetch(`${base}${path}`, {
    method,
    headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(body ? { 'Content-Type': 'application/json' } : {}) },
    body: body ? JSON.stringify(body) : undefined
  });
  let response = await request('GET', '/api/inquiries');
  assert.equal(response.status, 401);
  response = await request('GET', '/api/inquiries', customer.generateJwt());
  assert.equal(response.status, 403);
  const staffToken = staff.generateJwt();
  response = await request('GET', '/api/inquiries?page=1', staffToken);
  assert.equal(response.status, 200);
  let page = await response.json();
  assert.equal(page.total, 21);
  assert.equal(page.items.length, 20);
  assert.equal(page.pageCount, 2);
  assert.equal(page.items[0].message, 'Please tell me about this trip.');
  assert.match(page.items[0].referenceNumber, /^INQ-\d{8}-[A-F0-9]{8}$/);
  assert.ok(Number.isInteger(page.items[0].travelerCount));
  response = await request('GET', '/api/inquiries?page=2', staffToken);
  assert.equal((await response.json()).items.length, 1);
  for (const path of ['/api/inquiries?page=0', '/api/inquiries?status=all', '/api/inquiries?page=1&page=2']) {
    response = await request('GET', path, staffToken);
    assert.equal(response.status, 400);
  }
  const id = inquiries[0]._id.toString();
  response = await request('PATCH', `/api/inquiries/${id}/status`, customer.generateJwt(), { status: 'closed' });
  assert.equal(response.status, 403);
  response = await request('PATCH', `/api/inquiries/${id}/status`, staffToken, { status: 'closed', email: 'changed@example.test' });
  assert.equal(response.status, 400);
  response = await request('PATCH', `/api/inquiries/${id}/status`, staffToken, { status: 'other' });
  assert.equal(response.status, 400);
  response = await request('PATCH', `/api/inquiries/${id}/status`, staffToken, { status: 'in_progress' });
  assert.equal(response.status, 200);
  assert.equal((await response.json()).status, 'in_progress');
  response = await request('GET', '/api/inquiries?status=in_progress', staffToken);
  page = await response.json();
  assert.equal(page.total, 1);
  assert.equal(page.items[0]._id, id);
  response = await request('PATCH', `/api/inquiries/${id}/status`, staffToken, { status: 'closed' });
  assert.equal(response.status, 200);
  assert.equal((await Inquiry.findById(id)).status, 'closed');
  response = await request('POST', '/api/register', undefined, { name: 'Self Register', email: 'self@example.test', password: 'test-only-password', role: 'staff' });
  assert.equal(response.status, 200);
  assert.equal((await User.findOne({ email: 'self@example.test' })).role, 'customer');
  // A token issued while staff must stop working as soon as its database role changes.
  await User.updateOne({ _id: staff._id }, { $set: { role: 'customer' } });
  response = await request('GET', '/api/inquiries', staffToken);
  assert.equal(response.status, 403);
  console.log('PASS: staff-only access, pagination/filtering, safe status updates, registration role, and role revocation.');
}

run().catch(error => { console.error(error); process.exitCode = 1; }).finally(async () => {
  if (server) await new Promise(resolve => server.close(resolve));
  if (mongoose.connection.readyState === 1 && mongoose.connection.name === testDatabase && /^cs465_staff_test_[a-f0-9]{32}$/.test(testDatabase)) {
    await mongoose.connection.dropDatabase();
  }
  await mongoose.disconnect();
});
