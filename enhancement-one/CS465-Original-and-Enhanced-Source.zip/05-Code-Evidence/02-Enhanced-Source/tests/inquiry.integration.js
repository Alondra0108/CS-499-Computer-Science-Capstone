/** Exercise the public inquiry flow in an isolated, disposable MongoDB database. */
const assert = require('node:assert/strict');
const { randomUUID, randomBytes } = require('node:crypto');
const { once } = require('node:events');
const mongoose = require('mongoose');
const testDatabase = `cs465_inquiry_test_${randomUUID().replaceAll('-', '')}`;
process.env.DB_NAME = testDatabase;
process.env.DB_HOST = '127.0.0.1:27017';
process.env.JWT_SECRET = randomBytes(32).toString('hex');
let server;

async function run() {
  const connected = once(mongoose.connection, 'connected');
  const app = require('../app');
  await connected;
  const Trip = require('../app_api/models/travlr');
  const Inquiry = require('../app_api/models/inquiry');
  await Trip.create({ code: 'INQUIRY1', name: 'Reef Escape', length: '2 days', start: '2026-10-01', resort: 'Ocean', image: 'reef.jpg', description: 'A test trip', perPerson: 125.5 });
  server = app.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const base = `http://127.0.0.1:${server.address().port}`;
  process.env.TRIPS_API_URL = `${base}/api/trips`;
  const path = '/travel/INQUIRY1/inquiry';
  let response = await fetch(`${base}/travel`);
  assert.match(await response.text(), /Ask about this trip/);
  response = await fetch(`${base}${path}`);
  assert.equal(response.status, 200);
  let html = await response.text();
  assert.match(html, /Reef Escape/);
  assert.match(html, /\$125\.50/);
  const token = html.match(/name="formToken" value="([^"]+)"/)?.[1];
  assert.ok(token);
  const submit = (fields, url = path) => fetch(`${base}${url}`, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(fields) });
  const inquiry = { formToken: token, fullName: '  María Rivera  ', email: '  MARIA@example.com  ', travelerCount: '2', message: '  Do you have a room for two?  ' };
  response = await submit({ ...inquiry, email: 'invalid', message: 'short' });
  assert.equal(response.status, 400);
  html = await response.text();
  assert.match(html, /Enter a valid email address/);
  assert.match(html, /value="María Rivera"/);
  assert.equal(await Inquiry.countDocuments(), 0);
  response = await submit({ ...inquiry, formToken: 'invalid' });
  assert.equal(response.status, 403);
  assert.equal(await Inquiry.countDocuments(), 0);
  response = await submit(inquiry, '/travel/WRONG/inquiry');
  assert.equal(response.status, 404);
  assert.equal(await Inquiry.countDocuments(), 0);
  response = await submit(inquiry);
  assert.equal(response.status, 303);
  const receiptPath = response.headers.get('location');
  assert.match(receiptPath, /^\/travel\/INQUIRY1\/inquiry\/sent\?receipt=/);
  const saved = await Inquiry.findOne({ tripCode: 'INQUIRY1' });
  assert.ok(saved);
  assert.equal(saved.tripName, 'Reef Escape');
  assert.equal(saved.fullName, 'María Rivera');
  assert.equal(saved.email, 'maria@example.com');
  assert.equal(saved.travelerCount, 2);
  assert.equal(saved.message, 'Do you have a room for two?');
  assert.equal(saved.status, 'new');
  assert.match(saved.referenceNumber, /^INQ-\d{8}-[A-F0-9]{8}$/);
  response = await fetch(`${base}${path}/sent`);
  assert.equal(response.status, 404);
  response = await fetch(`${base}${receiptPath}`);
  assert.equal(response.status, 200);
  html = await response.text();
  assert.match(html, /saved for review/);
  assert.match(html, new RegExp(saved.referenceNumber));
  assert.equal(await Inquiry.countDocuments(), 1);
  console.log('PASS: trip-linked form, validation, signed token, saved inquiry, staff status and redirect confirmation.');
}

run().catch(error => { console.error(error); process.exitCode = 1; }).finally(async () => {
  if (server) await new Promise(resolve => server.close(resolve));
  if (mongoose.connection.readyState === 1 && mongoose.connection.name === testDatabase && /^cs465_inquiry_test_[a-f0-9]{32}$/.test(testDatabase)) {
    await mongoose.connection.dropDatabase();
  }
  await mongoose.disconnect();
});
