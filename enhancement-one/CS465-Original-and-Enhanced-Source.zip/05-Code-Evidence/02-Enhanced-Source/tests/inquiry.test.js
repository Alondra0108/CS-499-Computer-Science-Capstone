/** Validate the saved fields independently of the browser controls. */
const test = require('node:test');
const assert = require('node:assert/strict');
const { validateInquiry } = require('../app_server/utils/inquiry-validation');

test('trims valid inquiry values and accepts ordinary names, emails and questions', () => {
  const { values, errors } = validateInquiry({ fullName: '  María Rivera  ', email: '  Maria@example.com  ', travelerCount: ' 2 ', message: '  Do you have a room for two?  ' });
  assert.deepEqual(errors, {});
  assert.deepEqual(values, { fullName: 'María Rivera', email: 'Maria@example.com', travelerCount: '2', message: 'Do you have a room for two?' });
});

test('rejects missing, malformed and repeated values with field-specific errors', () => {
  for (const body of [
    {}, { fullName: ['One', 'Two'], email: 'a@example.com', travelerCount: '2', message: 'A question for you' },
    { fullName: 'A', email: 'not an email', travelerCount: '0', message: 'short' },
    { fullName: 'Normal Name', email: 'a@example.com', travelerCount: '21', message: 'x'.repeat(2001) },
    { fullName: 'Normal Name', email: 'a@example.com', travelerCount: '2.5', message: 'A question for you' }
  ]) {
    const result = validateInquiry(body);
    assert.ok(Object.keys(result.errors).length);
    assert.ok(result.values.fullName.length <= 100);
    assert.ok(result.values.message.length <= 2000);
  }
});
