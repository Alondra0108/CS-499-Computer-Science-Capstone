/** Local-only smoke test. Writes exclusively to a unique temporary test database. */
const assert = require('node:assert/strict');
const { randomUUID, randomBytes } = require('node:crypto');
const { once } = require('node:events');
const mongoose = require('mongoose');
const testDatabase = `cs465_price_test_${randomUUID().replaceAll('-', '')}`;
process.env.DB_NAME = testDatabase;
process.env.DB_HOST = '127.0.0.1:27017';
process.env.JWT_SECRET = randomBytes(32).toString('hex');
let server;
const realFetch = global.fetch;

async function run() {
  const connected = once(mongoose.connection, 'connected');
  const app = require('../app');
  await connected;
  const Trip = require('../app_api/models/travlr');
  const User = require('../app_api/models/user');
  const staff = new User({ name: 'Price Test Staff', email: 'price-staff@example.test', role: 'staff' });
  staff.setPassword(randomBytes(16).toString('hex'));
  await staff.save();
  server = app.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const base = `http://127.0.0.1:${server.address().port}`;
  // Route the public controller's internal API call to this test server only.
  process.env.TRIPS_API_URL = `${base}/api/trips`;
  const headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${staff.generateJwt()}` };
  const sample = { code: 'PRICE_TEST', name: 'Price Test', length: '2 days', start: '2026-10-01', resort: 'Test', image: 'reef.jpg', description: 'Test', perPerson: 125.5 };
  const request = (method, url, body) => realFetch(`${base}${url}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });

  let response = await request('POST', '/api/trips', sample);
  assert.equal(response.status, 201);
  assert.equal((await response.json()).perPerson, 125.5);
  let record = await mongoose.connection.db.collection('trips').findOne({ code: sample.code });
  assert.equal(record.perPerson._bsontype, 'Decimal128');
  assert.equal(record.perPerson.toString(), '125.50');
  response = await request('GET', `/api/trips/${sample.code}`);
  assert.equal((await response.json())[0].perPerson, 125.5);

  response = await request('PUT', `/api/trips/${sample.code}`, { ...sample, perPerson: 99.99 });
  assert.equal(response.status, 201);
  assert.equal((await response.json()).perPerson, 99.99);
  for (const price of [-1, '99.99', '', null, 1.001]) {
    response = await request('PUT', `/api/trips/${sample.code}`, { ...sample, perPerson: price });
    assert.equal(response.status, 400);
  }
  record = await mongoose.connection.db.collection('trips').findOne({ code: sample.code });
  assert.equal(record.perPerson.toString(), '99.99');
  response = await request('GET', '/travel');
  assert.equal(response.status, 200);
  assert.match(await response.text(), /\$99\.99 per person/);

  response = await request('PUT', `/api/trips/${sample.code}`, { ...sample, perPerson: 0 });
  assert.equal(response.status, 201);
  assert.equal((await response.json()).perPerson, 0);
  await Trip.create([{ ...sample, code: 'TWENTY', perPerson: 20 }, { ...sample, code: 'HUNDRED', perPerson: 100 }]);
  const sorted = await Trip.find({}).sort({ perPerson: 1 });
  assert.deepEqual(sorted.map(t => t.toJSON().perPerson), [0, 20, 100]);
  const filtered = await Trip.find({ perPerson: { $gte: mongoose.Types.Decimal128.fromString('20.00') } });
  assert.equal(filtered.length, 2);
  response = await request('DELETE', `/api/trips/${sample.code}`);
  assert.equal(response.status, 200);
  assert.equal((await response.json()).perPerson, 0);
  console.log('PASS: API create/read/update/delete, rejection, exact Decimal128 storage, numeric sorting/filtering, and public currency display.');
}

run().catch(error => { console.error(error); process.exitCode = 1; }).finally(async () => {
  global.fetch = realFetch;
  if (server) await new Promise(resolve => server.close(resolve));
  // Only the randomly named database created by this run may be removed.
  if (mongoose.connection.readyState === 1 && mongoose.connection.name === testDatabase && /^cs465_price_test_[a-f0-9]{32}$/.test(testDatabase)) {
    await mongoose.connection.dropDatabase();
  }
  await mongoose.disconnect();
});
