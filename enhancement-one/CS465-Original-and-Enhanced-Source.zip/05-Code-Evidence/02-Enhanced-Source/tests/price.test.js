const { test } = require('node:test');
const assert = require('node:assert/strict');
const mongoose = require('mongoose');
const Trip = require('../app_api/models/travlr');
const { canonicalPrice, toDecimalPrice, isApiPrice, MAX_PRICE } = require('../app_api/utils/price');
const { formatPrice } = require('../app_server/utils/price-display');
const { tripsAddTrip, tripsUpdateTrip } = require('../app_api/controllers/trips');

const sample = { code: 'TEST', name: 'Test', length: '2 nights', start: '2026-10-01', resort: 'Test', image: 'reef.jpg', description: 'Test', perPerson: 19.99 };

test('valid prices retain dollars/cents and zero in Decimal128 and JSON', async () => {
  for (const price of [0, 0.01, 0.1, 19.99, 125, 799, 1199, 1999, 3499, MAX_PRICE]) {
    assert.equal(isApiPrice(price), true);
    const trip = new Trip({ ...sample, perPerson: price });
    await trip.validate();
    assert.ok(trip.perPerson instanceof mongoose.Types.Decimal128);
    assert.equal(trip.perPerson.toString(), canonicalPrice(price));
    assert.equal(JSON.parse(JSON.stringify(trip)).perPerson, price);
  }
});

test('legacy plain decimal strings migrate without changing amounts', () => {
  for (const [input, expected] of [['799.00', '799.00'], [' 00125.5 ', '125.50'], ['0', '0.00']]) {
    assert.equal(toDecimalPrice(input).toString(), expected);
  }
});

test('invalid values are rejected, never silently rounded or converted to zero', async () => {
  for (const price of ['', ' ', '$799.00', '1,199.00', 'NaN', 'Infinity', '1e2', '0x20', '-1', '1.001', null, undefined, true, [], {}, -1, NaN, Infinity, 0.001, MAX_PRICE + 1]) {
    assert.throws(() => toDecimalPrice(price));
    assert.equal(isApiPrice(price), false);
    await assert.rejects(new Trip({ ...sample, perPerson: price }).validate());
  }
  assert.equal(isApiPrice('125.00'), false, 'API requires a number even though migration accepts legacy text');
});

test('hydrate Decimal128 records and serialize numeric prices', () => {
  const trip = Trip.hydrate({ ...sample, perPerson: toDecimalPrice(125.5) });
  assert.equal(JSON.parse(JSON.stringify(trip)).perPerson, 125.5);
});

test('display formatting keeps two cents digits and never displays NaN', () => {
  assert.equal(formatPrice(125), '$125.00');
  assert.equal(formatPrice(1199.5), '$1,199.50');
  assert.equal(formatPrice(0), '$0.00');
  assert.equal(formatPrice(undefined), 'Price unavailable');
});

test('both write controllers reject invalid/missing prices before database access', async () => {
  for (const controller of [tripsAddTrip, tripsUpdateTrip]) {
    for (const price of [undefined, null, '', '125', true, -1, 1.001, MAX_PRICE + 1]) {
      let status, body;
      const res = { status(value) { status = value; return this; }, json(value) { body = value; return this; } };
      await controller({ body: { ...sample, perPerson: price }, params: { tripCode: 'TEST' } }, res);
      assert.equal(status, 400);
      assert.match(body.message, /Price must/);
    }
  }
});
