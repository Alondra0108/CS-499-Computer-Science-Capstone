/**
 * Search API + rendered-page regression checks against a disposable database.
 * Never write to the original or enhanced application databases.
 */
const assert = require('node:assert/strict');
const { randomUUID } = require('node:crypto');
const { once } = require('node:events');
const mongoose = require('mongoose');
const testDatabase = `cs465_search_test_${randomUUID().replaceAll('-', '')}`;
process.env.DB_NAME = testDatabase;
process.env.DB_HOST = '127.0.0.1:27017';
let server;

async function run() {
  const connected = once(mongoose.connection, 'connected');
  const app = require('../app');
  await connected;
  const Trip = require('../app_api/models/travlr');
  const common = { length: '2 days', resort: 'Ocean', image: 'reef.jpg', description: 'Search test' };
  await Trip.create([
    { ...common, code: 'A', name: 'Reef Escape', perPerson: 100, start: '2026-10-01T23:59:59.999Z' },
    { ...common, code: 'B', name: 'Beach', resort: 'Reef Resort', perPerson: 20, start: '2026-10-01T00:00:00Z' },
    { ...common, code: 'C', name: 'Mountain', perPerson: 0, start: '2026-10-02T00:00:00Z' },
    { ...common, code: 'D', name: 'Literal .* trip', perPerson: 200, start: '2026-09-30T00:00:00Z' }
  ]);
  server = app.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const base = `http://127.0.0.1:${server.address().port}`;
  process.env.TRIPS_API_URL = `${base}/api/trips`;
  async function codes(query) {
    const response = await fetch(`${base}/api/trips?${query}`);
    assert.equal(response.status, 200);
    return (await response.json()).map(trip => trip.code);
  }
  assert.deepEqual(await codes(''), ['D', 'B', 'A', 'C']);
  assert.deepEqual(await codes('q=REEF&minPrice=20&maxPrice=100&startDate=2026-10-01&endDate=2026-10-01&sort=priceDesc'), ['A', 'B']);
  assert.deepEqual(await codes('sort=priceAsc'), ['C', 'B', 'A', 'D']);
  assert.deepEqual(await codes('minPrice=0&maxPrice=0'), ['C']);
  assert.deepEqual(await codes('q=.*'), ['D']);
  assert.deepEqual(await codes('q=notfound'), []);
  for (const query of ['q=a&q=b', 'minPrice[$gt]=1', 'sort=invalid', 'startDate=2026-02-30', 'minPrice=100&maxPrice=20']) {
    const response = await fetch(`${base}/api/trips?${query}`);
    assert.equal(response.status, 400, query);
    assert.ok((await response.json()).errors);
  }
  let response = await fetch(`${base}/travel?q=Reef&maxPrice=20&sort=priceAsc`);
  assert.equal(response.status, 200);
  let html = await response.text();
  assert.match(html, /value="Reef"/);
  assert.match(html, /\$20\.00 per person/);
  assert.doesNotMatch(html, /\$100\.00 per person/);
  assert.match(html, /value="priceAsc" selected/);
  response = await fetch(`${base}/travel?q=notfound`);
  assert.equal(response.status, 200);
  assert.match(await response.text(), /No trips match/);
  response = await fetch(`${base}/travel?minPrice=100&maxPrice=20`);
  assert.equal(response.status, 400);
  assert.match(await response.text(), /Maximum price must be at least/);
  response = await fetch(`${base}/travel?q=${encodeURIComponent('<script>alert(1)</script>')}`);
  html = await response.text();
  assert.doesNotMatch(html, /<script>alert\(1\)<\/script>/);
  assert.match(html, /&lt;script&gt;/);

  // Simulate a failed query without stopping the user's MongoDB service.
  const originalFind = Trip.find;
  try {
    Trip.find = () => { throw new Error('PRIVATE_DATABASE_DETAILS'); };
    response = await fetch(`${base}/api/trips`);
    assert.equal(response.status, 503);
    assert.doesNotMatch(await response.text(), /PRIVATE_DATABASE_DETAILS/);
    response = await fetch(`${base}/travel`);
    assert.equal(response.status, 503);
    html = await response.text();
    assert.match(html, /Unable to retrieve trips/);
    assert.doesNotMatch(html, /PRIVATE_DATABASE_DETAILS/);
  } finally { Trip.find = originalFind; }
  console.log('PASS: combined filters, numeric sorting, inclusive dates, literal text, validation, retained form values, empty results, escaping and safe failure messages.');
}

run().catch(error => { console.error(error); process.exitCode = 1; }).finally(async () => {
  if (server) await new Promise(resolve => server.close(resolve));
  if (mongoose.connection.readyState === 1 && mongoose.connection.name === testDatabase && /^cs465_search_test_[a-f0-9]{32}$/.test(testDatabase)) {
    await mongoose.connection.dropDatabase();
  }
  await mongoose.disconnect();
});
