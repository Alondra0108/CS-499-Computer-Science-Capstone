const test = require('node:test');
const assert = require('node:assert/strict');
const { safeTripDescription } = require('../app_server/utils/trip-description');

test('trip descriptions retain paragraphs while removing executable markup', () => {
  const input = '<p onclick="alert(1)">Safe text</p><script>alert(1)</script><img src=x onerror=alert(1)>';
  assert.equal(safeTripDescription(input), '<p>Safe text</p>');
});

test('trip descriptions safely handle missing and plain-text values', () => {
  assert.equal(safeTripDescription(undefined), '');
  assert.equal(safeTripDescription('A calm reef & a quiet beach'), 'A calm reef &amp; a quiet beach');
});
