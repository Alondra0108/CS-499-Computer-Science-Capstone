/** Search contract regression tests: no database or customer data needed. */
const test = require('node:test');
const assert = require('node:assert/strict');
const { buildTripSearch, SearchValidationError, SORT_OPTIONS } = require('../app_api/utils/trip-search');

test('empty search has no filters and uses deterministic departure order', () => {
  const result = buildTripSearch({ q: '  ', minPrice: '' });
  assert.deepEqual(result.filter, {});
  assert.deepEqual(result.sort, { start: 1, _id: 1 });
});

test('search trims text and treats regex characters literally, ignoring case', () => {
  const { filter, criteria } = buildTripSearch({ q: '  Reef.* [A]  ' });
  assert.equal(criteria.q, 'Reef.* [A]');
  assert.ok(filter.$or[0].name.test('reef.* [a] vacation'));
  assert.ok(!filter.$or[0].name.test('Reefanything A'));
  assert.ok(filter.$or[1].resort.test('REEF.* [A]'));
});

test('combined price and date bounds preserve zero and the entire end day', () => {
  const { filter } = buildTripSearch({ q: 'reef', minPrice: '0', maxPrice: '100.25', startDate: '2028-02-28', endDate: '2028-02-29' });
  assert.equal(filter.perPerson.$gte.toString(), '0.00');
  assert.equal(filter.perPerson.$lte.toString(), '100.25');
  assert.equal(filter.start.$gte.toISOString(), '2028-02-28T00:00:00.000Z');
  assert.equal(filter.start.$lt.toISOString(), '2028-03-01T00:00:00.000Z');
  assert.ok(filter.$or);
});

test('invalid inputs fail with field errors instead of becoming database queries', () => {
  const cases = [
    [{ q: 'a'.repeat(101) }, 'q'], [{ q: ['a', 'b'] }, 'q'],
    [{ minPrice: { $gt: 0 } }, 'minPrice'], [{ minPrice: '-1' }, 'minPrice'],
    [{ maxPrice: '1.001' }, 'maxPrice'], [{ maxPrice: 'NaN' }, 'maxPrice'],
    [{ maxPrice: '1000000000' }, 'maxPrice'], [{ minPrice: '10', maxPrice: '0' }, 'maxPrice'],
    [{ startDate: '2026-02-29' }, 'startDate'], [{ endDate: '2026-04-31' }, 'endDate'],
    [{ startDate: '2026-10-02', endDate: '2026-10-01' }, 'endDate'],
    [{ sort: '$where' }, 'sort'], [{ $where: 'anything' }, 'query']
  ];
  for (const [input, field] of cases) {
    assert.throws(() => buildTripSearch(input), error => error instanceof SearchValidationError && Boolean(error.errors[field]));
  }
});

test('every allowed sort includes a unique tie breaker and returns a fresh object', () => {
  for (const option of SORT_OPTIONS) {
    const result = buildTripSearch({ sort: option.value });
    assert.deepEqual(result.sort, option.order);
    assert.notEqual(result.sort, option.order);
    assert.equal(result.sort._id, 1);
  }
});
