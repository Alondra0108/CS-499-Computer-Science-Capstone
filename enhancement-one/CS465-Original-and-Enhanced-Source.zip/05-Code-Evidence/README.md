# Source-Code Evidence

## Original source

`01-Original-Source` was copied from `Desktop/originalsourcecode/cs465-fullstack`. It was verified against `Desktop/cs465-fullstack.zip` after excluding dependencies, Git metadata, environment files, caches, and compiled output.

## Enhanced source

`02-Enhanced-Source` was copied from `Desktop/CS465-Capstone-Enhanced`. This is the completed implementation documented in the Enhancement One narrative and revised software design document.

## Excluded files

The package excludes `node_modules`, `.git`, `.env`, `.DS_Store`, Angular caches, coverage output, compiled `dist` files, and local backup folders. These exclusions keep the submission reproducible, secure, and reasonably sized. Dependencies can be restored with `npm install`.

