# CS 465 Enhancement — Automated Test Results

**Artifact:** Travlr Getaways Full-Stack Application  
**Category:** Software Design and Engineering  
**Student:** Alondra Paulino Santos  
**Evidence verified:** October 10–11, 2026

## Summary

The enhanced application passed all unit, component, and integration test suites. Together, these tests verify the new validation rules, accurate price handling, search and filtering behavior, customer inquiry workflow, authentication, role-based authorization, and staff inquiry-management functions.

The HTTP `400`, `401`, `403`, `404`, and `503` responses visible in some screenshots are intentional negative-path tests. They demonstrate that the application rejects invalid input, blocks unauthorized users, handles missing resources, and returns safe errors when a database request fails. They are not failed tests.

## Test Evidence

| Evidence | Command | Result | What the result verifies |
|---|---|---|---|
| `01-backend-unit-tests.png` | `npm test` | **15 passed, 0 failed** | Trimming and validating inquiry data, exact numeric price handling, safe trip descriptions, search validation, deterministic sorting, and controller validation before database access. |
| `02-angular-tests.png` | `npm test -- --watch=false` from `app_admin` | **8 test files and 16 tests passed** | Angular components and services, price validation, numeric form values, add/edit trip behavior, trip listing, and inquiry-list behavior. |
| `03-price-integration.png` | `npm run test:integration` | **Passed** | API create/read/update/delete operations, rejection of invalid prices, exact MongoDB `Decimal128` storage, numeric sorting and filtering, and public currency display. |
| `04-search-integration.png` | `npm run test:search` | **Passed** | Combined text, price, and date filters; numeric sorting; inclusive end dates; literal treatment of special characters; retained form values; empty results; validation; and safe failure messages. |
| `05-inquiry-integration.png` | `npm run test:inquiry` with the receipt value redacted from displayed output | **Passed** | Trip-linked inquiry form, server-side validation, signed confirmation receipt, saved inquiry, staff-only status information, and redirect confirmation. |
| `06-staff-integration.png` | `npm run test:staff` | **Passed** | Staff-only access, authentication and authorization responses, pagination, status filtering, allowlisted status updates, safe invalid-update rejection, secure registration role behavior, and immediate role revocation enforcement. |

## Security and Test-Data Notes

- The customer-inquiry screenshot uses `[REDACTED]` in place of the signed receipt token so that authentication-related evidence can be shown safely.
- The integration suites use isolated test databases and disconnect from MongoDB after completion.
- The evidence does not include passwords, production credentials, or private database connection strings.

## Overall Verification

These results provide repeatable evidence that the enhancement was implemented and tested across the server, API, database, public application, and administrator interface. The evidence also demonstrates both successful workflows and controlled rejection of unsafe, invalid, or unauthorized requests.
