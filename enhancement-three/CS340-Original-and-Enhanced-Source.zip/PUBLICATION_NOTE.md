# Publication Note

The original CS 340 notebook is included for before-and-after comparison. Its classroom MongoDB password was replaced with `REDACTED_BEFORE_PUBLICATION` in this public portfolio copy. The original local artifact was not altered.

The enhanced artifact uses environment-based configuration through `.env.example` and does not store operational credentials in source code.
