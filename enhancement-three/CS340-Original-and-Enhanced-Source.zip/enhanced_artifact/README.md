# Grazioso Salvare Animal Rescue Dashboard Database Enhancement

## Purpose

This directory contains the enhanced version of Alondra Paulino Santos's CS 340
Project Two artifact for the CS 499 database category. The original files remain
in the parent project directory for before-and-after comparison.

The enhancement preserves the dashboard's rescue-filtering purpose while moving
filtering, sorting, pagination, counting, and breed aggregation into MongoDB.
Only one requested page is transferred to the interface, while the chart still
summarizes the complete matching result set.

## Enhanced files

- `animal_shelter.py` provides validated CRUD operations, deterministic database
  paging, aggregation, error separation, and index-analysis helpers.
- `dashboard.py` provides the enhanced Dash application and safe user-query
  translation.
- `rescue_queries.py` centralizes the approved rescue-category rules shared by
  the dashboard and performance-evaluation utility.
- `index_evaluation.py` records existing indexes and comparable execution
  statistics. It does not create the documented candidate index unless the
  `--create-candidate` flag is supplied.
- `assets/GraziosoSalvareLogo.png` provides the original course-project
  branding as a locally served dashboard asset.
- `.env.example` documents required configuration names without real secrets.
- `tests/` contains isolated unit tests that do not modify a live database.

## Security decisions

Real credentials are not stored in source code. The application accepts only
approved filter and sort fields, translates a limited set of comparison
operations, caps page sizes, rejects empty update/delete queries, logs technical
database failures, and provides safe messages to dashboard users.

## Configuration

Set the following environment variables before starting the dashboard:

```text
MONGODB_USERNAME
MONGODB_PASSWORD
MONGODB_HOST
MONGODB_PORT
MONGODB_DATABASE
MONGODB_COLLECTION
MONGODB_AUTH_SOURCE
```

Defaults for nonsecret settings appear in `.env.example`. Do not place a real
password in `.env.example`, the notebook, screenshots, recordings, or Git.

## Install and run

From the `enhanced` directory:

```bash
python -m pip install -r requirements.txt
python dashboard.py
```

Open the local URL shown by Dash. The dashboard presents the original Grazioso
Salvare course-project logo alongside a readable title and author line.

## Logo provenance

The Grazioso Salvare logo is the original image distributed for the SNHU CS 340
course artifact. The recovered PNG was verified against two independently
published copies of the same course project; both copies had the same filename,
dimensions, file size, and SHA-256 checksum. The asset is stored locally so the
dashboard does not contact a third-party server while running.

## Tests

Run the isolated test suite from the `enhanced` directory:

```bash
python -m unittest discover -s tests -v
```

The tests cover query boundaries, sort stability, page limiting, identifier
serialization, aggregation construction, destructive-operation safeguards,
filter parsing, and coordinate validation. A live MongoDB verification should
also be performed with the course dataset before final submission.

## Index evaluation

First record the baseline with the current database:

```bash
python index_evaluation.py --output index_baseline.json
```

Review the existing indexes and candidate trade-offs. If the candidate is
appropriate, create it and repeat the identical queries:

```bash
python index_evaluation.py --create-candidate --output index_candidate.json
```

Compare returned-record counts, documents examined, keys examined, and execution
time. Execution time alone can vary between runs, so conclusions should consider
all measurements and confirm that results remain correct. The candidate index
uses storage and adds maintenance cost to writes; it should be retained only when
the measured benefit justifies that cost.

## Live verification checklist

1. Start MongoDB with the Austin Animal Center dataset and a least-privilege user.
2. Verify All Animals and all three rescue categories.
3. Apply approved text and numeric column filters.
4. Sort by one and multiple columns and move through multiple pages.
5. Confirm that total counts and top-breed statistics use the same criteria.
6. Verify a successful empty result displays `No animals match`.
7. Stop MongoDB temporarily and confirm a separate safe failure message appears.
8. Select animals with valid, missing, and invalid coordinates.
9. Record baseline and candidate index evidence against the same dataset.
