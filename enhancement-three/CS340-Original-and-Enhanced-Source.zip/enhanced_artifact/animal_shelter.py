"""Secure MongoDB data-access services for the enhanced rescue dashboard.

Author: Alondra Paulino Santos
Course: CS 499 Computer Science Capstone
Artifact: CS 340 Grazioso Salvare Animal Rescue Dashboard
Enhancement category: Databases
Version: 2.0
Date: September 30, 2026

Intent and design decisions:
    This module keeps database responsibilities outside the Dash interface. It
    validates every dashboard-generated query, performs sorting and pagination
    in MongoDB, calculates breed summaries with an aggregation pipeline, and
    exposes index-analysis helpers. Credentials are supplied through environment
    variables by the application rather than embedded in source code.
"""

from __future__ import annotations

from dataclasses import dataclass
import logging
import math
from typing import Any, Iterable, Mapping, Sequence
from urllib.parse import quote_plus

from bson import ObjectId
from pymongo import ASCENDING, DESCENDING, MongoClient
from pymongo.collection import Collection
from pymongo.errors import PyMongoError


LOGGER = logging.getLogger(__name__)

MAX_PAGE_SIZE = 100
DEFAULT_PAGE_SIZE = 10

# The dashboard may query only these known dataset fields. Keeping this list at
# the data boundary prevents arbitrary field and operator injection.
ALLOWED_FILTER_FIELDS = {
    "animal_id",
    "animal_type",
    "breed",
    "color",
    "name",
    "outcome_type",
    "sex_upon_outcome",
    "age_upon_outcome_in_weeks",
}

ALLOWED_SORT_FIELDS = ALLOWED_FILTER_FIELDS | {"datetime", "monthyear", "_id"}
ALLOWED_COMPARISON_OPERATORS = {"$eq", "$ne", "$gt", "$gte", "$lt", "$lte", "$in"}

# A projection limits network transfer to information the enhanced dashboard
# displays or uses. MongoDB's _id remains available as a stable tie-breaker.
DASHBOARD_PROJECTION = {
    "animal_id": 1,
    "animal_type": 1,
    "breed": 1,
    "color": 1,
    "name": 1,
    "outcome_type": 1,
    "sex_upon_outcome": 1,
    "age_upon_outcome_in_weeks": 1,
    "location_lat": 1,
    "location_long": 1,
}


class DatabaseOperationError(RuntimeError):
    """Represent a database failure without exposing connection details to UI code."""


@dataclass(frozen=True)
class PageResult:
    """One database page plus the metadata required by the dashboard."""

    records: list[dict[str, Any]]
    total_count: int
    page_number: int
    page_size: int

    @property
    def page_count(self) -> int:
        """Return the number of available pages, including zero for no matches."""

        return math.ceil(self.total_count / self.page_size) if self.total_count else 0


def _require_non_empty_text(value: Any, name: str) -> str:
    """Validate required configuration while keeping messages free of secrets."""

    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be a non-empty string.")
    return value.strip()


def _validate_scalar(value: Any, field: str) -> Any:
    """Allow predictable BSON-safe scalar values for dashboard filters."""

    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    raise ValueError(f"Unsupported value type for filter field '{field}'.")


def validate_query(query: Mapping[str, Any] | None) -> dict[str, Any]:
    """Return a defensive copy of an allow-listed dashboard query.

    Rescue rules and user filters are joined with ``$and``. Nested ``$and`` is
    therefore allowed, but user-supplied top-level database operators are not.
    Each field may contain a scalar equality value or a small, approved set of
    comparison operators.
    """

    if query is None:
        return {}
    if not isinstance(query, Mapping):
        raise ValueError("Query must be a mapping.")

    # Build a new dictionary instead of mutating or trusting the caller's data.
    # This ensures that only values examined by this function reach PyMongo.
    validated: dict[str, Any] = {}
    for field, condition in query.items():
        if field == "$and":
            # The dashboard joins the selected rescue category and optional
            # column filters with $and. Each nested part is validated again.
            if not isinstance(condition, Sequence) or isinstance(condition, (str, bytes)):
                raise ValueError("$and must contain a sequence of query mappings.")
            validated["$and"] = [validate_query(part) for part in condition]
            continue

        if field not in ALLOWED_FILTER_FIELDS:
            raise ValueError(f"Filtering by '{field}' is not permitted.")

        if isinstance(condition, Mapping):
            # A condition such as {"$gte": 26} must use an approved comparison
            # operator. Database scripting and raw regex operators are rejected.
            safe_condition: dict[str, Any] = {}
            for operator, value in condition.items():
                if operator not in ALLOWED_COMPARISON_OPERATORS:
                    raise ValueError(f"Operator '{operator}' is not permitted.")
                if operator == "$in":
                    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
                        raise ValueError("$in requires a list of values.")
                    safe_condition[operator] = [_validate_scalar(item, field) for item in value]
                else:
                    safe_condition[operator] = _validate_scalar(value, field)
            validated[field] = safe_condition
        else:
            validated[field] = _validate_scalar(condition, field)
    return validated


def validate_sort(sort: Sequence[tuple[str, int]] | None) -> list[tuple[str, int]]:
    """Validate sort fields and append ``_id`` for deterministic pagination."""

    # Rebuild the sort specification so a browser request cannot inject an
    # arbitrary database field or unsupported sort value.
    normalized: list[tuple[str, int]] = []
    for field, direction in sort or []:
        if field not in ALLOWED_SORT_FIELDS:
            raise ValueError(f"Sorting by '{field}' is not permitted.")
        if direction not in (ASCENDING, DESCENDING):
            raise ValueError("Sort direction must be ascending or descending.")
        if field != "_id":
            normalized.append((field, direction))

    # Stable ordering prevents records with equal values from moving between
    # pages while a user browses the same result set.
    normalized.append(("_id", ASCENDING))
    return normalized


def serialize_document(document: Mapping[str, Any]) -> dict[str, Any]:
    """Convert BSON-only values to dashboard-safe representations."""

    serialized = dict(document)
    if "_id" in serialized:
        serialized["_id"] = str(serialized["_id"])
    return serialized


class AnimalShelter:
    """Provide validated CRUD, paging, aggregation, and index operations."""

    def __init__(
        self,
        username: str,
        password: str,
        host: str = "localhost",
        port: int = 27017,
        database_name: str = "aac",
        collection_name: str = "animals",
        auth_source: str = "admin",
        *,
        client: MongoClient | None = None,
        connect_timeout_ms: int = 5000,
    ) -> None:
        """Connect to MongoDB or accept an injected client for isolated tests."""

        username = _require_non_empty_text(username, "MongoDB username")
        password = _require_non_empty_text(password, "MongoDB password")
        host = _require_non_empty_text(host, "MongoDB host")
        database_name = _require_non_empty_text(database_name, "Database name")
        collection_name = _require_non_empty_text(collection_name, "Collection name")
        auth_source = _require_non_empty_text(auth_source, "Authentication source")
        if not isinstance(port, int) or not 1 <= port <= 65535:
            raise ValueError("MongoDB port must be between 1 and 65535.")

        try:
            if client is None:
                # quote_plus protects reserved URI characters in credentials.
                # The completed URI is never logged or returned to the browser.
                uri = (
                    f"mongodb://{quote_plus(username)}:{quote_plus(password)}@"
                    f"{host}:{port}/?authSource={quote_plus(auth_source)}"
                )
                client = MongoClient(uri, serverSelectionTimeoutMS=connect_timeout_ms)
            # Selecting the database and collection here keeps those connection
            # details out of the dashboard's presentation logic.
            self.client = client
            self.database = self.client[database_name]
            self.collection: Collection = self.database[collection_name]
            # Ping fails fast during startup instead of waiting for the first
            # user action to reveal an authentication or connectivity problem.
            self.client.admin.command("ping")
        except PyMongoError as exc:
            LOGGER.exception("MongoDB connection failed.")
            raise DatabaseOperationError("The database connection could not be established.") from exc

    def close(self) -> None:
        """Release the MongoDB client's network resources."""

        self.client.close()

    def create(self, data: Mapping[str, Any]) -> str:
        """Insert one non-empty document and return its identifier."""

        if not isinstance(data, Mapping) or not data:
            raise ValueError("Create data must be a non-empty mapping.")
        try:
            result = self.collection.insert_one(dict(data))
            return str(result.inserted_id)
        except PyMongoError as exc:
            LOGGER.exception("Create operation failed.")
            raise DatabaseOperationError("The record could not be created.") from exc

    def read(self, query: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
        """Read validated records for compatibility with the original artifact."""

        safe_query = validate_query(query)
        try:
            return [serialize_document(item) for item in self.collection.find(safe_query)]
        except PyMongoError as exc:
            LOGGER.exception("Read operation failed.")
            raise DatabaseOperationError("The records could not be loaded.") from exc

    def find_page(
        self,
        query: Mapping[str, Any] | None,
        *,
        page_number: int = 0,
        page_size: int = DEFAULT_PAGE_SIZE,
        sort: Sequence[tuple[str, int]] | None = None,
        projection: Mapping[str, int] | None = None,
    ) -> PageResult:
        """Return one deterministically sorted MongoDB page and total count."""

        if not isinstance(page_number, int) or page_number < 0:
            raise ValueError("Page number must be a nonnegative integer.")
        if not isinstance(page_size, int) or not 1 <= page_size <= MAX_PAGE_SIZE:
            raise ValueError(f"Page size must be between 1 and {MAX_PAGE_SIZE}.")

        # Validate every user-influenced value before constructing the cursor.
        safe_query = validate_query(query)
        safe_sort = validate_sort(sort)
        safe_projection = dict(projection or DASHBOARD_PROJECTION)
        safe_projection["_id"] = 1

        try:
            # Count uses the same filter as the page query. The interface uses
            # this number to calculate pages and describe the complete result.
            total_count = self.collection.count_documents(safe_query)
            page_count = math.ceil(total_count / page_size) if total_count else 0
            # A filter change can make the browser's previous page invalid.
            # Returning to page zero produces a useful, predictable result.
            safe_page = page_number if page_count == 0 or page_number < page_count else 0
            # MongoDB performs sorting, skipping, and limiting before documents
            # cross the network, so the browser receives one requested page.
            cursor = (
                self.collection.find(safe_query, safe_projection)
                .sort(safe_sort)
                .skip(safe_page * page_size)
                .limit(page_size)
            )
            records = [serialize_document(item) for item in cursor]
            return PageResult(records, total_count, safe_page, page_size)
        except PyMongoError as exc:
            LOGGER.exception("Paged read operation failed.")
            raise DatabaseOperationError("The requested page could not be loaded.") from exc

    def aggregate_breed_counts(
        self, query: Mapping[str, Any] | None, limit: int = 10
    ) -> list[dict[str, Any]]:
        """Summarize breeds across every matching record, not one table page."""

        if not isinstance(limit, int) or not 1 <= limit <= 50:
            raise ValueError("Aggregation limit must be between 1 and 50.")
        safe_query = validate_query(query)
        # This pipeline deliberately repeats the table's validated filter. It
        # summarizes all matching animals, not only the current table page.
        pipeline = [
            {"$match": safe_query},
            {"$match": {"breed": {"$ne": None}}},
            {"$group": {"_id": "$breed", "count": {"$sum": 1}}},
            {"$sort": {"count": -1, "_id": 1}},
            {"$limit": limit},
            {"$project": {"_id": 0, "breed": "$_id", "count": 1}},
        ]
        try:
            return list(self.collection.aggregate(pipeline))
        except PyMongoError as exc:
            LOGGER.exception("Breed aggregation failed.")
            raise DatabaseOperationError("Breed statistics could not be loaded.") from exc

    def update(self, query: Mapping[str, Any], new_values: Mapping[str, Any]) -> int:
        """Update matching records while rejecting an accidental update-all call."""

        safe_query = validate_query(query)
        if not safe_query:
            raise ValueError("Update requires a non-empty query.")
        if not isinstance(new_values, Mapping) or not new_values:
            raise ValueError("Update values must be a non-empty mapping.")
        # Restrict updates to the predictable $set operation. Replacement and
        # scripting-style updates are outside this artifact's requirements.
        if set(new_values) != {"$set"} or not isinstance(new_values["$set"], Mapping):
            raise ValueError("Only a non-empty $set update is permitted.")
        if not new_values["$set"]:
            raise ValueError("$set must include at least one field.")
        try:
            return self.collection.update_many(safe_query, dict(new_values)).modified_count
        except PyMongoError as exc:
            LOGGER.exception("Update operation failed.")
            raise DatabaseOperationError("The records could not be updated.") from exc

    def delete(self, query: Mapping[str, Any]) -> int:
        """Delete matching records while rejecting an accidental delete-all call."""

        safe_query = validate_query(query)
        if not safe_query:
            raise ValueError("Delete requires a non-empty query.")
        try:
            return self.collection.delete_many(safe_query).deleted_count
        except PyMongoError as exc:
            LOGGER.exception("Delete operation failed.")
            raise DatabaseOperationError("The records could not be deleted.") from exc

    def list_indexes(self) -> list[dict[str, Any]]:
        """Return current index metadata so evaluation starts from evidence."""

        try:
            return list(self.collection.list_indexes())
        except PyMongoError as exc:
            LOGGER.exception("Index inspection failed.")
            raise DatabaseOperationError("Indexes could not be inspected.") from exc

    def create_index(self, keys: Iterable[tuple[str, int]], name: str) -> str:
        """Create one reviewed compound index; this is never called automatically."""

        # Index creation is an explicit evaluation action, never an automatic
        # side effect of starting the public dashboard.
        key_list = list(keys)
        if not key_list:
            raise ValueError("An index requires at least one field.")
        for field, direction in key_list:
            if field not in ALLOWED_SORT_FIELDS or direction not in (ASCENDING, DESCENDING):
                raise ValueError("Index specification contains an unsupported field or direction.")
        try:
            return self.collection.create_index(key_list, name=name)
        except PyMongoError as exc:
            LOGGER.exception("Index creation failed.")
            raise DatabaseOperationError("The index could not be created.") from exc

    def explain_find(
        self,
        query: Mapping[str, Any] | None,
        sort: Sequence[tuple[str, int]] | None = None,
    ) -> dict[str, Any]:
        """Return execution statistics for repeatable before-and-after evaluation."""

        safe_query = validate_query(query)
        safe_sort = validate_sort(sort)
        try:
            # executionStats supplies returned, examined-document, examined-key,
            # and timing evidence for the same query before and after indexing.
            command = {
                "explain": {
                    "find": self.collection.name,
                    "filter": safe_query,
                    "sort": dict(safe_sort),
                    "limit": DEFAULT_PAGE_SIZE,
                },
                "verbosity": "executionStats",
            }
            return self.database.command(command)
        except PyMongoError as exc:
            LOGGER.exception("Query explanation failed.")
            raise DatabaseOperationError("Query statistics could not be collected.") from exc
