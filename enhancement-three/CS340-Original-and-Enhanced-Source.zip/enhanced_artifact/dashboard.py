"""Enhanced Dash interface for the Grazioso Salvare rescue database.

Author: Alondra Paulino Santos
Course: CS 499 Computer Science Capstone
Artifact: CS 340 Grazioso Salvare Animal Rescue Dashboard
Enhancement category: Databases
Version: 2.0
Date: September 30, 2026

Enhancement summary:
    The original interface loaded every matching MongoDB document before the
    browser paged and sorted the results. This version sends validated filters,
    sorting, and page requests to MongoDB. It also requests a database-wide
    breed aggregation for the chart, preserves display-safe record identifiers,
    validates coordinates, distinguishes no matches from database failures, and
    reads connection settings from the environment instead of source code.
"""

from __future__ import annotations

import logging
import math
import os
import re
from typing import Any, Mapping

import dash_leaflet as dl
from dash import Dash, Input, Output, State, callback, dash_table, dcc, html
import plotly.express as px
from pymongo import ASCENDING, DESCENDING

from animal_shelter import (
    MAX_PAGE_SIZE,
    AnimalShelter,
    DatabaseOperationError,
)
from rescue_queries import RESCUE_QUERIES


logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
LOGGER = logging.getLogger(__name__)

DEFAULT_CENTER = [30.2672, -97.7431]
DEFAULT_PAGE_SIZE = 10

DISPLAY_COLUMNS = [
    "animal_id",
    "name",
    "animal_type",
    "breed",
    "color",
    "sex_upon_outcome",
    "age_upon_outcome_in_weeks",
    "outcome_type",
]

FILTERABLE_COLUMNS = set(DISPLAY_COLUMNS)
NUMERIC_COLUMNS = {"age_upon_outcome_in_weeks"}

def load_database() -> AnimalShelter:
    """Create the data service from required environment configuration."""

    # Secret values are read at runtime. They are not assigned defaults because
    # a placeholder credential could hide a deployment configuration mistake.
    username = os.getenv("MONGODB_USERNAME")
    password = os.getenv("MONGODB_PASSWORD")
    if not username or not password:
        raise RuntimeError(
            "Set MONGODB_USERNAME and MONGODB_PASSWORD before starting the dashboard."
        )

    try:
        port = int(os.getenv("MONGODB_PORT", "27017"))
    except ValueError as exc:
        raise RuntimeError("MONGODB_PORT must be an integer.") from exc

    # Nonsecret connection settings have documented local-development defaults.
    return AnimalShelter(
        username=username,
        password=password,
        host=os.getenv("MONGODB_HOST", "localhost"),
        port=port,
        database_name=os.getenv("MONGODB_DATABASE", "aac"),
        collection_name=os.getenv("MONGODB_COLLECTION", "animals"),
        auth_source=os.getenv("MONGODB_AUTH_SOURCE", "admin"),
    )


def combine_queries(*queries: Mapping[str, Any]) -> dict[str, Any]:
    """Combine non-empty query parts without silently overwriting conditions."""

    # $and preserves conditions when the rescue rule and a user filter target
    # the same field; dictionary merging could silently overwrite one of them.
    parts = [dict(query) for query in queries if query]
    if not parts:
        return {}
    if len(parts) == 1:
        return parts[0]
    return {"$and": parts}


def _coerce_filter_value(field: str, raw_value: str) -> Any:
    """Convert approved numeric filter values while leaving text as text."""

    # Dash includes surrounding quotes for text filters. Removing only the
    # outer quote characters leaves the intended literal value for MongoDB.
    value = raw_value.strip().strip('"').strip("'")
    if len(value) > 100:
        raise ValueError("Filter values may not exceed 100 characters.")
    if field in NUMERIC_COLUMNS:
        try:
            return float(value)
        except ValueError as exc:
            raise ValueError(f"{field} requires a numeric value.") from exc
    return value


FILTER_EXPRESSION = re.compile(
    r"^\{(?P<field>[A-Za-z0-9_]+)\}\s*"
    r"(?P<operator>eq|ne|ge|le|gt|lt|=|!=|>=|<=|>|<)\s*"
    r"(?P<value>.+)$"
)

OPERATOR_MAP = {
    "eq": "$eq",
    "=": "$eq",
    "ne": "$ne",
    "!=": "$ne",
    "ge": "$gte",
    ">=": "$gte",
    "le": "$lte",
    "<=": "$lte",
    "gt": "$gt",
    ">": "$gt",
    "lt": "$lt",
    "<": "$lt",
}


def parse_table_filter(filter_query: str | None) -> dict[str, Any]:
    """Translate Dash filter expressions into an allow-listed MongoDB query.

    Dash joins column expressions with ``&&``. This parser intentionally
    supports comparison operations only. It does not accept raw JSON, regular
    expressions, JavaScript, or MongoDB operators from the browser.
    """

    if not filter_query or not filter_query.strip():
        return {}

    # Parse each expression individually instead of accepting browser-provided
    # JSON. That creates a narrow, explainable boundary for database access.
    conditions: list[dict[str, Any]] = []
    for expression in filter_query.split(" && "):
        match = FILTER_EXPRESSION.fullmatch(expression.strip())
        if not match:
            raise ValueError(
                "Use filters such as {breed} eq 'Labrador Retriever Mix' or "
                "{age_upon_outcome_in_weeks} ge 26."
            )
        # Field and operation checks happen before the value becomes a query.
        field = match.group("field")
        if field not in FILTERABLE_COLUMNS:
            raise ValueError(f"Filtering by '{field}' is not available.")
        value = _coerce_filter_value(field, match.group("value"))
        conditions.append({field: {OPERATOR_MAP[match.group("operator")]: value}})

    return conditions[0] if len(conditions) == 1 else {"$and": conditions}


def parse_sort(sort_by: list[dict[str, str]] | None) -> list[tuple[str, int]]:
    """Translate Dash sort selections into validated PyMongo directions."""

    # DataTable reports human-readable directions; PyMongo uses 1 and -1.
    parsed: list[tuple[str, int]] = []
    for item in sort_by or []:
        column = item.get("column_id")
        if column not in FILTERABLE_COLUMNS:
            raise ValueError(f"Sorting by '{column}' is not available.")
        direction = ASCENDING if item.get("direction") == "asc" else DESCENDING
        parsed.append((column, direction))
    return parsed


def valid_coordinates(record: Mapping[str, Any]) -> tuple[float, float] | None:
    """Return verified latitude and longitude or ``None`` for invalid data."""

    # Conversion rejects missing fields and nonnumeric strings before the map
    # component sees them.
    try:
        latitude = float(record["location_lat"])
        longitude = float(record["location_long"])
    except (KeyError, TypeError, ValueError):
        return None
    # Finite and geographic-range checks prevent NaN, infinity, or impossible
    # coordinates from producing a misleading marker.
    if not (math.isfinite(latitude) and math.isfinite(longitude)):
        return None
    if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
        return None
    return latitude, longitude


try:
    database = load_database()
    STARTUP_ERROR = ""
except (RuntimeError, ValueError) as exc:
    # Missing or malformed local configuration is actionable and expected in a
    # newly copied project, so it is logged without an unnecessary traceback.
    LOGGER.warning("Dashboard configuration is incomplete: %s", exc)
    database = None
    STARTUP_ERROR = "Database access is unavailable. Check the server configuration."
except DatabaseOperationError:
    # The page can still load and explain the configuration problem without
    # displaying credentials, host details, or a Python traceback to the user.
    LOGGER.exception("Dashboard database initialization failed.")
    database = None
    STARTUP_ERROR = "Database access is unavailable. Check the server configuration."


app = Dash(__name__)
app.title = "Grazioso Salvare Animal Rescue Dashboard"

app.layout = html.Div(
    style={"fontFamily": "Arial, sans-serif", "padding": "24px", "maxWidth": "1500px", "margin": "auto"},
    children=[
        # Dash serves project images from the assets directory. Keeping the
        # logo local avoids a runtime dependency on an external website, while
        # alternative text preserves the header's meaning for screen readers.
        html.Header(
            style={
                "display": "flex",
                "alignItems": "center",
                "gap": "22px",
                "flexWrap": "wrap",
            },
            children=[
                html.Img(
                    src=app.get_asset_url("GraziosoSalvareLogo.png"),
                    alt="Grazioso Salvare logo featuring a stylized rescue dog",
                    style={"width": "120px", "height": "120px", "objectFit": "contain"},
                ),
                html.Div(
                    [
                        html.H1(
                            "Grazioso Salvare Animal Rescue Dashboard",
                            style={"margin": "0 0 0.35rem"},
                        ),
                        html.P(
                            "Enhanced CS 340 database artifact by Alondra Paulino Santos",
                            style={"margin": "0"},
                        ),
                    ]
                ),
            ],
        ),
        html.Hr(),
        html.H3("Rescue Category"),
        dcc.RadioItems(
            id="filter-type",
            value="reset",
            inline=True,
            options=[
                {"label": "Water Rescue", "value": "water"},
                {"label": "Mountain / Wilderness Rescue", "value": "mountain"},
                {"label": "Disaster / Individual Tracking", "value": "disaster"},
                {"label": "All Animals", "value": "reset"},
            ],
        ),
        html.P(
            "Column-filter examples: {breed} eq 'German Shepherd' or "
            "{age_upon_outcome_in_weeks} ge 26",
            style={"color": "#555", "fontSize": "0.9rem"},
        ),
        html.Div(id="status-message", role="status", style={"padding": "10px 0", "fontWeight": "bold"}),
        dcc.Store(id="breed-count-store", data=[]),
        dash_table.DataTable(
            id="datatable-id",
            columns=[{"name": field.replace("_", " ").title(), "id": field} for field in DISPLAY_COLUMNS],
            data=[],
            filter_action="custom",
            filter_query="",
            sort_action="custom",
            sort_mode="multi",
            sort_by=[],
            page_action="custom",
            page_current=0,
            page_size=DEFAULT_PAGE_SIZE,
            page_count=0,
            row_selectable="single",
            selected_rows=[],
            editable=False,
            style_table={"overflowX": "auto"},
            style_cell={"textAlign": "left", "padding": "7px", "fontFamily": "Arial", "fontSize": "14px"},
            style_header={"fontWeight": "bold", "backgroundColor": "#E8EEF4"},
        ),
        html.Br(),
        html.Div(
            style={"display": "flex", "gap": "24px", "flexWrap": "wrap"},
            children=[
                html.Div(id="graph-id", style={"flex": "1 1 500px"}),
                html.Div(id="map-id", style={"flex": "1 1 500px"}),
            ],
        ),
    ],
)


@callback(
    Output("datatable-id", "data"),
    Output("datatable-id", "page_count"),
    Output("datatable-id", "page_current"),
    Output("datatable-id", "selected_rows"),
    Output("breed-count-store", "data"),
    Output("status-message", "children"),
    Input("filter-type", "value"),
    Input("datatable-id", "filter_query"),
    Input("datatable-id", "sort_by"),
    Input("datatable-id", "page_current"),
    Input("datatable-id", "page_size"),
)
def update_dashboard(
    rescue_type: str,
    filter_query: str,
    sort_by: list[dict[str, str]],
    page_current: int,
    page_size: int,
):
    """Retrieve one page and matching aggregate statistics from MongoDB."""

    # A missing connection leaves the page usable and produces a safe status
    # message instead of allowing the callback to raise an uncaught exception.
    if database is None:
        return [], 0, 0, [], [], STARTUP_ERROR

    try:
        # Convert interface choices into one database query, then use that exact
        # query for the table page and the breed summary.
        rescue_query = RESCUE_QUERIES.get(rescue_type, {})
        user_query = parse_table_filter(filter_query)
        combined_query = combine_queries(rescue_query, user_query)
        # find_page performs count, sort, skip, and limit in MongoDB.
        result = database.find_page(
            combined_query,
            page_number=page_current or 0,
            page_size=page_size or DEFAULT_PAGE_SIZE,
            sort=parse_sort(sort_by),
        )
        breed_counts = database.aggregate_breed_counts(combined_query)
    except ValueError as exc:
        return [], 0, 0, [], [], f"Invalid filter or paging option: {exc}"
    except DatabaseOperationError:
        return [], 0, 0, [], [], "Animal records could not be loaded. Please try again."

    # A successful empty result is intentionally different from the database
    # failure handled above, giving the user an accurate explanation.
    if result.total_count == 0:
        return [], 0, 0, [], breed_counts, "No animals match the selected criteria."

    status = (
        f"Showing page {result.page_number + 1} of {result.page_count}; "
        f"{result.total_count:,} matching animals."
    )
    return (
        result.records,
        result.page_count,
        result.page_number,
        [0] if result.records else [],
        breed_counts,
        status,
    )


@callback(Output("graph-id", "children"), Input("breed-count-store", "data"))
def update_graph(breed_counts: list[dict[str, Any]]):
    """Render MongoDB's aggregate summary for the complete filtered result."""

    if not breed_counts:
        return html.P("No breed statistics are available for the selected criteria.")
    # The server already returned ordered aggregate results, so this callback
    # only turns the database summary into a readable horizontal bar chart.
    figure = px.bar(
        breed_counts,
        x="count",
        y="breed",
        orientation="h",
        title="Top Breeds Across All Matching Animals",
        labels={"count": "Animals", "breed": "Breed"},
    )
    figure.update_layout(yaxis={"categoryorder": "total ascending"})
    return dcc.Graph(figure=figure)


@callback(
    Output("map-id", "children"),
    Input("datatable-id", "data"),
    Input("datatable-id", "selected_rows"),
)
def update_map(records: list[dict[str, Any]], selected_rows: list[int]):
    """Display the selected animal only when its coordinates are supported."""

    map_children: list[Any] = [dl.TileLayer(id="base-layer-id")]
    center = DEFAULT_CENTER
    message = "Select an animal with valid coordinates to display its location."

    if records:
        # Filtering or paging can invalidate an earlier selection. Defaulting
        # to row zero connects the marker to a record on the displayed page.
        row = selected_rows[0] if selected_rows and selected_rows[0] < len(records) else 0
        record = records[row]
        coordinates = valid_coordinates(record)
        if coordinates:
            # A marker is created only from coordinates validated above. The
            # application never invents a location for an incomplete record.
            latitude, longitude = coordinates
            center = [latitude, longitude]
            breed = str(record.get("breed") or "Unknown breed")
            name = str(record.get("name") or "Unnamed animal")
            map_children.append(
                dl.Marker(
                    position=center,
                    children=[dl.Tooltip(breed), dl.Popup([html.H4(name), html.P(breed)])],
                )
            )
            message = ""
        else:
            message = "The selected animal does not have valid map coordinates."

    return html.Div(
        [
            html.P(message) if message else None,
            dl.Map(
                center=center,
                zoom=10,
                children=map_children,
                style={"width": "100%", "height": "500px"},
            ),
        ]
    )


if __name__ == "__main__":
    # Debug mode is configurable and disabled by default for safer execution.
    debug_enabled = os.getenv("DASH_DEBUG", "false").lower() == "true"
    app.run(debug=debug_enabled, host=os.getenv("DASH_HOST", "127.0.0.1"), port=int(os.getenv("DASH_PORT", "8050")))
