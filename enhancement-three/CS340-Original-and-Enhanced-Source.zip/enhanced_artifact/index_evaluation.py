"""Collect repeatable MongoDB index evidence for the CS 499 enhancement.

Author: Alondra Paulino Santos
Version: 2.0
Date: September 30, 2026

This script never creates an index unless ``--create-candidate`` is supplied.
Run it once for a baseline, review the candidate against the actual dataset,
then run it with the flag and compare the generated execution statistics.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any

from pymongo import ASCENDING

from animal_shelter import AnimalShelter
from rescue_queries import RESCUE_QUERIES


CANDIDATE_INDEX = [
    ("animal_type", ASCENDING),
    ("sex_upon_outcome", ASCENDING),
    ("age_upon_outcome_in_weeks", ASCENDING),
    ("breed", ASCENDING),
]
CANDIDATE_NAME = "rescue_filter_compound_v1"


def _execution_summary(explanation: dict[str, Any]) -> dict[str, Any]:
    """Keep the comparable execution figures and omit verbose server details."""

    stats = explanation.get("executionStats", {})
    return {
        "n_returned": stats.get("nReturned"),
        "execution_time_ms": stats.get("executionTimeMillis"),
        "total_keys_examined": stats.get("totalKeysExamined"),
        "total_documents_examined": stats.get("totalDocsExamined"),
    }


def configured_database() -> AnimalShelter:
    """Build the same environment-configured connection used by the dashboard."""

    return AnimalShelter(
        username=os.environ["MONGODB_USERNAME"],
        password=os.environ["MONGODB_PASSWORD"],
        host=os.getenv("MONGODB_HOST", "localhost"),
        port=int(os.getenv("MONGODB_PORT", "27017")),
        database_name=os.getenv("MONGODB_DATABASE", "aac"),
        collection_name=os.getenv("MONGODB_COLLECTION", "animals"),
        auth_source=os.getenv("MONGODB_AUTH_SOURCE", "admin"),
    )


def main() -> None:
    """Inspect indexes, optionally create one candidate, and save comparable evidence."""

    parser = argparse.ArgumentParser(description="Evaluate a reviewed rescue-query index.")
    parser.add_argument(
        "--create-candidate",
        action="store_true",
        help="Create the documented compound-index candidate before collecting statistics.",
    )
    parser.add_argument(
        "--output",
        default="index_evaluation_results.json",
        help="Path for the evidence file.",
    )
    args = parser.parse_args()

    # Reuse the same configuration and data-access class as the dashboard so
    # the evaluation reflects the deployed collection and validation rules.
    database = configured_database()
    try:
        # Preserve the starting index inventory. This prevents an unsupported
        # claim that the original collection had no useful indexes.
        existing_before = database.list_indexes()
        if args.create_candidate:
            # Creation is intentionally opt-in after baseline evidence is saved.
            database.create_index(CANDIDATE_INDEX, CANDIDATE_NAME)

        evaluations = {}
        for category in ("water", "mountain", "disaster"):
            # All categories use the same sorting and limit so before-and-after
            # statistics remain comparable.
            explanation = database.explain_find(
                RESCUE_QUERIES[category],
                sort=[("age_upon_outcome_in_weeks", ASCENDING)],
            )
            evaluations[category] = _execution_summary(explanation)

        # The JSON output records measurements and the design trade-off together,
        # making the final performance claim auditable in the ePortfolio.
        evidence = {
            "candidate_created_for_this_run": args.create_candidate,
            "candidate_name": CANDIDATE_NAME,
            "candidate_fields": CANDIDATE_INDEX,
            "existing_indexes_before_run": existing_before,
            "existing_indexes_after_run": database.list_indexes(),
            "query_execution_statistics": evaluations,
            "trade_off_note": (
                "The candidate may reduce reads for rescue filters, but every additional "
                "index consumes storage and adds maintenance work to inserts and updates."
            ),
        }
        Path(args.output).write_text(json.dumps(evidence, indent=2, default=str), encoding="utf-8")
        print(f"Index evidence written to {args.output}")
    finally:
        database.close()


if __name__ == "__main__":
    main()
