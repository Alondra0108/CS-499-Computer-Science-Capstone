"""Approved rescue-category query definitions shared by the application tools.

Author: Alondra Paulino Santos
Version: 2.0
Date: September 30, 2026

Keeping these definitions outside the user interface lets the dashboard and the
index-evaluation utility execute identical queries without importing one another
or creating an unnecessary database connection.
"""

from typing import Any


# These dictionaries preserve the rescue rules from the original CS 340
# artifact. The enhanced version changes where and how they are executed: they
# now participate in validated, paged queries and full-result aggregation.
RESCUE_QUERIES: dict[str, dict[str, Any]] = {
    "reset": {},
    "water": {
        "animal_type": "Dog",
        "breed": {
            "$in": [
                "Labrador Retriever Mix",
                "Chesapeake Bay Retriever",
                "Newfoundland",
            ]
        },
        "sex_upon_outcome": "Intact Female",
        "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
    },
    "mountain": {
        "animal_type": "Dog",
        "breed": {
            "$in": [
                "German Shepherd",
                "Alaskan Malamute",
                "Old English Sheepdog",
                "Siberian Husky",
                "Rottweiler",
            ]
        },
        "sex_upon_outcome": "Intact Male",
        "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
    },
    "disaster": {
        "animal_type": "Dog",
        "breed": {
            "$in": [
                "Doberman Pinscher",
                "German Shepherd",
                "Golden Retriever",
                "Bloodhound",
                "Rottweiler",
            ]
        },
        "sex_upon_outcome": "Intact Male",
        "age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300},
    },
}
