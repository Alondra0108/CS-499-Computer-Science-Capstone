"""Unit tests for validation, paging, aggregation, and destructive safeguards."""

from __future__ import annotations

import unittest
from unittest.mock import MagicMock

from bson import ObjectId
from pymongo import ASCENDING, DESCENDING

from animal_shelter import (
    DASHBOARD_PROJECTION,
    AnimalShelter,
    PageResult,
    serialize_document,
    validate_query,
    validate_sort,
)


class AnimalShelterTests(unittest.TestCase):
    """Exercise enhancement logic without requiring a live MongoDB server."""

    def setUp(self) -> None:
        self.collection = MagicMock()
        self.database = MagicMock()
        self.service = AnimalShelter.__new__(AnimalShelter)
        self.service.collection = self.collection
        self.service.database = self.database
        self.service.client = MagicMock()

    def test_query_allows_expected_rescue_conditions(self) -> None:
        query = {
            "$and": [
                {"animal_type": "Dog"},
                {"breed": {"$in": ["Newfoundland", "Bloodhound"]}},
                {"age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}},
            ]
        }
        self.assertEqual(validate_query(query), query)

    def test_query_rejects_unapproved_fields_and_operators(self) -> None:
        with self.assertRaises(ValueError):
            validate_query({"password": "secret"})
        with self.assertRaises(ValueError):
            validate_query({"breed": {"$where": "malicious"}})

    def test_sort_adds_unique_identifier_tie_breaker(self) -> None:
        self.assertEqual(
            validate_sort([("breed", DESCENDING)]),
            [("breed", DESCENDING), ("_id", ASCENDING)],
        )

    def test_find_page_limits_work_in_database_and_serializes_id(self) -> None:
        document_id = ObjectId()
        cursor = MagicMock()
        cursor.sort.return_value = cursor
        cursor.skip.return_value = cursor
        cursor.limit.return_value = [{"_id": document_id, "breed": "Newfoundland"}]
        self.collection.find.return_value = cursor
        self.collection.count_documents.return_value = 21

        result = self.service.find_page(
            {"animal_type": "Dog"}, page_number=1, page_size=10, sort=[("breed", ASCENDING)]
        )

        self.assertIsInstance(result, PageResult)
        self.assertEqual(result.total_count, 21)
        self.assertEqual(result.page_count, 3)
        self.assertEqual(result.page_number, 1)
        self.assertEqual(result.records[0]["_id"], str(document_id))
        cursor.skip.assert_called_once_with(10)
        cursor.limit.assert_called_once_with(10)
        projection = dict(DASHBOARD_PROJECTION)
        projection["_id"] = 1
        self.collection.find.assert_called_once_with({"animal_type": "Dog"}, projection)

    def test_invalid_page_returns_to_first_page(self) -> None:
        cursor = MagicMock()
        cursor.sort.return_value = cursor
        cursor.skip.return_value = cursor
        cursor.limit.return_value = []
        self.collection.find.return_value = cursor
        self.collection.count_documents.return_value = 5

        result = self.service.find_page({}, page_number=9, page_size=10)
        self.assertEqual(result.page_number, 0)
        cursor.skip.assert_called_once_with(0)

    def test_aggregation_uses_match_group_sort_limit_and_projection(self) -> None:
        expected = [{"breed": "Labrador Retriever Mix", "count": 12}]
        self.collection.aggregate.return_value = expected
        result = self.service.aggregate_breed_counts({"animal_type": "Dog"})
        self.assertEqual(result, expected)

        pipeline = self.collection.aggregate.call_args.args[0]
        self.assertEqual(pipeline[0], {"$match": {"animal_type": "Dog"}})
        self.assertIn("$group", pipeline[2])
        self.assertEqual(pipeline[4], {"$limit": 10})

    def test_update_and_delete_reject_empty_queries(self) -> None:
        with self.assertRaises(ValueError):
            self.service.update({}, {"$set": {"name": "Test"}})
        with self.assertRaises(ValueError):
            self.service.delete({})

    def test_serialize_document_preserves_identifier_as_text(self) -> None:
        document_id = ObjectId()
        result = serialize_document({"_id": document_id, "name": "Teddy"})
        self.assertEqual(result, {"_id": str(document_id), "name": "Teddy"})


if __name__ == "__main__":
    unittest.main()
