"""Unit tests for safe filter translation and map-coordinate validation."""

from __future__ import annotations

import os
import unittest
from unittest.mock import patch

# Placeholder configuration and a mocked service keep module import isolated
# from MongoDB while allowing the dashboard's pure helper functions to be tested.
with patch.dict(
    os.environ,
    {"MONGODB_USERNAME": "test-user", "MONGODB_PASSWORD": "test-password"},
):
    with patch("animal_shelter.AnimalShelter"):
        import dashboard


class DashboardLogicTests(unittest.TestCase):
    def test_combines_rescue_and_user_filters(self) -> None:
        combined = dashboard.combine_queries(
            {"animal_type": "Dog"}, {"age_upon_outcome_in_weeks": {"$gte": 26}}
        )
        self.assertEqual(combined["$and"][0], {"animal_type": "Dog"})
        self.assertEqual(
            combined["$and"][1], {"age_upon_outcome_in_weeks": {"$gte": 26}}
        )

    def test_parses_approved_text_and_numeric_filters(self) -> None:
        query = dashboard.parse_table_filter(
            "{breed} eq 'German Shepherd' && {age_upon_outcome_in_weeks} ge 26"
        )
        self.assertEqual(query["$and"][0], {"breed": {"$eq": "German Shepherd"}})
        self.assertEqual(
            query["$and"][1], {"age_upon_outcome_in_weeks": {"$gte": 26.0}}
        )

    def test_rejects_unapproved_filter_field(self) -> None:
        with self.assertRaises(ValueError):
            dashboard.parse_table_filter("{password} eq 'secret'")

    def test_coordinate_validation(self) -> None:
        self.assertEqual(
            dashboard.valid_coordinates({"location_lat": 30.25, "location_long": -97.75}),
            (30.25, -97.75),
        )
        self.assertIsNone(
            dashboard.valid_coordinates({"location_lat": 130, "location_long": -97.75})
        )
        self.assertIsNone(dashboard.valid_coordinates({"name": "No location"}))


if __name__ == "__main__":
    unittest.main()
