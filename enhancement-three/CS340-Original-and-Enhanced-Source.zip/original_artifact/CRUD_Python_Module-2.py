# Example Python Code to Insert a Document

from pymongo import MongoClient
from bson.objectid import ObjectId
import logging


# Use logging instead of print() for errors (more professional / industry standard).
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        """
        Initialize MongoDB connection.

        Parameters:
            username (str): MongoDB username (ex: 'aacuser')
            password (str): MongoDB password

        Notes:
            - Connects to the aac database and animals collection
            - Authenticates against the admin database (per SNHU examples)
        """
        # Initializing the MongoClient to access MongoDB
        # This connects to the aac database and animals collection
        # using the aacuser account
        USER = username
        PASS = password
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        # Validate credentials early so errors are clear and consistent.
        # (Industry standard: validate inputs before attempting network calls.)
        if not isinstance(USER, str) or not isinstance(PASS, str) or USER == "" or PASS == "":
            raise ValueError("MongoDB username and password must be non-empty strings.")

        try:
            # Create the MongoDB client connection
            self.client = MongoClient(
                'mongodb://%s:%s@%s:%d/admin' % (USER, PASS, HOST, PORT)
            )

            # Access the specified database and collection
            self.database = self.client['%s' % (DB)]
            self.collection = self.database['%s' % (COL)]

            # Optional connection check (fails fast if auth/connection is wrong)
            self.client.admin.command('ping')

        except Exception as e:
            # Log the error and re-raise so the calling code knows connection failed.
            logger.error("MongoDB connection failed: %s", e)
            raise

    # Create method to insert a document into the animals collection
    def create(self, data):
        """
        Insert one document into MongoDB.

        Parameters:
            data (dict): Document to insert.

        Returns:
            bool: True if insert succeeds, otherwise False.
        """
        # Industry standard: validate inputs and fail safely.
        if data is None or not isinstance(data, dict) or len(data) == 0:
            logger.warning("Create failed: data must be a non-empty dictionary.")
            return False

        try:
            # Insert the document into MongoDB
            self.collection.insert_one(data)
            return True

        except Exception as e:
            logger.error("Create failed: %s", e)
            return False

    # Read method to retrieve documents from the animals collection
    def read(self, query):
        """
        Retrieve documents using a MongoDB query.

        Parameters:
            query (dict): Query filter. Use {} to retrieve all.

        Returns:
            list: Matching documents (empty list if none found or error).
        """
        results = []

        # Treat None as "retrieve all" to avoid crashes and support edge-case testing.
        if query is None:
            query = {}

        # Validate query format
        if not isinstance(query, dict):
            logger.warning("Read failed: query must be a dictionary.")
            return results

        try:
            # Find matching documents using the query dictionary
            cursor = self.collection.find(query)
            for document in cursor:
                results.append(document)

        except Exception as e:
            logger.error("Read failed: %s", e)

        # Return a list of matching documents (or empty list if none found)
        return results

    # Update method to change document(s) in the animals collection
    def update(self, query, new_values):
        """
        Update matching document(s) using a query and MongoDB update operation.

        Parameters:
            query (dict): Query filter to match documents.
            new_values (dict): Update operation, ex: {"$set": {"color": "Black"}}

        Returns:
            int: Number of documents modified (0 if none modified or error).
        """
        if query is not None and new_values is not None:
            # Validate types for industry-standard robustness
            if not isinstance(query, dict) or not isinstance(new_values, dict):
                logger.warning("Update failed: query and new_values must be dictionaries.")
                return 0

            try:
                # Update matching document(s) using the query and update data
                # new_values must be in the format accepted by MongoDB, such as:
                # {"$set": {"color": "Black"}}
                result = self.collection.update_many(query, new_values)
                return result.modified_count

            except Exception as e:
                logger.error("Update failed: %s", e)
                return 0
        else:
            return 0

    # Delete method to remove document(s) from the animals collection
    def delete(self, query):
        """
        Delete matching document(s) using a MongoDB query.

        Parameters:
            query (dict): Query filter to match documents for deletion.

        Returns:
            int: Number of documents deleted (0 if none deleted or error).
        """
        if query is not None:
            # Validate query type (prevents common edge-case crashes)
            if not isinstance(query, dict):
                logger.warning("Delete failed: query must be a dictionary.")
                return 0

            try:
                # Delete matching document(s) using the query
                result = self.collection.delete_many(query)
                return result.deleted_count

            except Exception as e:
                logger.error("Delete failed: %s", e)
                return 0
        else:
            return 0