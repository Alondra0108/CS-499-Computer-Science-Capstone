// CS300_Capstone_Enhanced.cpp
// Alondra Paulino Santos
// CS 499 - Algorithms and Data Structures Enhancement
//
// Capstone Course Planning Assistant
// -----------------------------------
// This program enhances the original CS 300 Advising Assistance Program. It
// retains a custom hash table with separate chaining for course storage and
// adds a directed prerequisite graph with Kahn's topological-sort algorithm.
// The generated order places every prerequisite before the courses that depend
// on it. Invalid records, missing prerequisites, self-dependencies, and cycles
// are reported instead of being silently removed from the planning data.
//
// Expected input format:
//   COURSE_NUMBER,COURSE_TITLE[,PREREQUISITE_1,PREREQUISITE_2,...]
//
// The CSV reader supports quoted fields and escaped quotation marks. Course
// codes are normalized by removing spaces and hyphens and converting letters
// to uppercase so inputs such as "cs 300" and "CS-300" match "CS300".

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstddef>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <memory>
#include <queue>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace advising {

using Clock = std::chrono::steady_clock;

// -----------------------------------------------------------------------------
// Domain model and input-normalization helpers
// -----------------------------------------------------------------------------

// A Course is the central record shared by the hash table, search functions,
// and prerequisite graph. Prerequisites are stored as normalized course codes.
struct Course {
    std::string number;
    std::string title;
    std::vector<std::string> prerequisites;
};

std::string Trim(const std::string& value) {
    std::size_t first = 0;
    while (first < value.size() &&
           std::isspace(static_cast<unsigned char>(value[first]))) {
        ++first;
    }

    std::size_t last = value.size();
    while (last > first &&
           std::isspace(static_cast<unsigned char>(value[last - 1]))) {
        --last;
    }
    return value.substr(first, last - first);
}

// Course-code normalization is performed at every input boundary before a
// value is hashed or compared. This keeps file data and user input consistent.
std::string NormalizeCourseCode(const std::string& rawCode) {
    std::string normalized;
    normalized.reserve(rawCode.size());

    for (char character : Trim(rawCode)) {
        const unsigned char byte = static_cast<unsigned char>(character);
        if (std::isspace(byte) || character == '-') {
            continue;
        }
        normalized.push_back(static_cast<char>(std::toupper(byte)));
    }
    return normalized;
}

// SNHU course codes used by this artifact contain an alphabetic department
// prefix followed by three digits, such as CS300, CSCI200, or MATH201.
bool IsValidCourseCode(const std::string& code) {
    // Find the boundary between the department prefix and numeric course level.
    std::size_t prefixLength = 0;
    while (prefixLength < code.size() &&
           std::isalpha(static_cast<unsigned char>(code[prefixLength]))) {
        ++prefixLength;
    }

    if (prefixLength < 2 || prefixLength > 5 ||
        code.size() - prefixLength != 3) {
        return false;
    }

    for (std::size_t index = prefixLength; index < code.size(); ++index) {
        if (!std::isdigit(static_cast<unsigned char>(code[index]))) {
            return false;
        }
    }
    return true;
}

struct Node {
    explicit Node(const Course& courseValue) : course(courseValue) {}

    Course course;
    std::unique_ptr<Node> next;
};

// -----------------------------------------------------------------------------
// Custom hash table with separate chaining
// -----------------------------------------------------------------------------

// The hash table owns each chain through unique_ptr. This prevents leaks and
// double deletion while preserving the separate-chaining design selected in
// the original CS 300 analysis. Copying is disabled; moving and Clear are safe.
class HashTable {
public:
    static constexpr std::size_t kDefaultBucketCount = 179;

    explicit HashTable(std::size_t bucketCount = kDefaultBucketCount)
        : buckets_(std::max<std::size_t>(bucketCount, 1)) {}

    HashTable(const HashTable&) = delete;
    HashTable& operator=(const HashTable&) = delete;
    HashTable(HashTable&&) noexcept = default;
    HashTable& operator=(HashTable&&) noexcept = default;
    ~HashTable() = default;

    bool Insert(const Course& course) {
        const std::size_t bucketIndex = Hash(course.number);

        // Traverse the selected chain before insertion so a duplicate key can
        // never create two records for the same course.
        for (Node* current = buckets_[bucketIndex].get(); current != nullptr;
             current = current->next.get()) {
            if (current->course.number == course.number) {
                return false;
            }
        }

        if (buckets_[bucketIndex] != nullptr) {
            // A nonempty bucket means the new key collided with an existing
            // key. Separate chaining preserves both records in the same bucket.
            ++collisionCount_;
        }

        // Insert at the front of the chain in constant time.
        auto node = std::make_unique<Node>(course);
        node->next = std::move(buckets_[bucketIndex]);
        buckets_[bucketIndex] = std::move(node);
        ++size_;
        return true;
    }

    const Course* Search(const std::string& rawCourseNumber) const {
        const std::string key = NormalizeCourseCode(rawCourseNumber);
        const std::size_t bucketIndex = Hash(key);

        // Only the computed bucket is traversed. With a well-distributed hash,
        // this provides approximately constant-time average lookup.
        for (const Node* current = buckets_[bucketIndex].get(); current != nullptr;
             current = current->next.get()) {
            if (current->course.number == key) {
                return &current->course;
            }
        }
        return nullptr;
    }

    std::vector<Course> ToVector() const {
        std::vector<Course> courses;
        courses.reserve(size_);

        for (const auto& bucket : buckets_) {
            for (const Node* current = bucket.get(); current != nullptr;
                 current = current->next.get()) {
                courses.push_back(current->course);
            }
        }
        return courses;
    }

    std::vector<Course> ToSortedVector() const {
        std::vector<Course> courses = ToVector();

        // Hash tables do not preserve a meaningful display order, so a copied
        // vector is sorted without changing the table's internal chains.
        std::sort(courses.begin(), courses.end(),
                  [](const Course& left, const Course& right) {
                      return left.number < right.number;
                  });
        return courses;
    }

    void Clear() noexcept {
        // Resetting each owning pointer releases the entire linked chain.
        for (auto& bucket : buckets_) {
            bucket.reset();
        }
        size_ = 0;
        collisionCount_ = 0;
    }

    bool Empty() const noexcept { return size_ == 0; }
    std::size_t Size() const noexcept { return size_; }
    std::size_t BucketCount() const noexcept { return buckets_.size(); }
    std::size_t CollisionCount() const noexcept { return collisionCount_; }

    double LoadFactor() const noexcept {
        return static_cast<double>(size_) /
               static_cast<double>(buckets_.size());
    }

    std::size_t MaximumChainLength() const noexcept {
        std::size_t maximum = 0;
        for (const auto& bucket : buckets_) {
            std::size_t length = 0;
            for (const Node* current = bucket.get(); current != nullptr;
                 current = current->next.get()) {
                ++length;
            }
            maximum = std::max(maximum, length);
        }
        return maximum;
    }

private:
    std::size_t Hash(const std::string& key) const {
        // std::hash supplies the hash value; modulo maps it to a valid bucket.
        return std::hash<std::string>{}(key) % buckets_.size();
    }

    std::vector<std::unique_ptr<Node>> buckets_;
    std::size_t size_ = 0;
    std::size_t collisionCount_ = 0;
};

// -----------------------------------------------------------------------------
// File-loading results and validation diagnostics
// -----------------------------------------------------------------------------

enum class IssueSeverity { kWarning, kError };

struct LoadIssue {
    std::size_t lineNumber = 0;
    IssueSeverity severity = IssueSeverity::kError;
    std::string category;
    std::string detail;
};

struct LoadResult {
    bool fileOpened = false;
    bool hasBlockingRecordErrors = false;
    std::size_t linesRead = 0;
    std::size_t blankLinesSkipped = 0;
    std::size_t parsedCourses = 0;
    std::size_t insertedCourses = 0;
    std::size_t duplicateCourses = 0;
    std::size_t missingPrerequisites = 0;
    std::size_t selfPrerequisites = 0;
    std::size_t duplicatePrerequisites = 0;
    long long elapsedMilliseconds = 0;
    std::vector<LoadIssue> issues;

    bool CanGeneratePlan() const {
        // These conditions cover errors known before topological sorting. A
        // cycle is discovered later when Kahn's algorithm processes the graph.
        return fileOpened && insertedCourses > 0 &&
               !hasBlockingRecordErrors && missingPrerequisites == 0 &&
               selfPrerequisites == 0;
    }
};

// Parses one CSV row while respecting quoted fields and doubled quotes. The
// parser intentionally reports unmatched quotation marks instead of accepting
// an ambiguous record.
bool ParseCsvFields(const std::string& line,
                    std::vector<std::string>& fields,
                    std::string& errorMessage) {
    fields.clear();
    std::string field;
    bool inQuotes = false;

    for (std::size_t index = 0; index < line.size(); ++index) {
        const char character = line[index];

        if (character == '"') {
            // Two consecutive quotation marks inside a quoted value represent
            // one literal quotation mark in CSV.
            if (inQuotes && index + 1 < line.size() && line[index + 1] == '"') {
                field.push_back('"');
                ++index;
            } else {
                inQuotes = !inQuotes;
            }
        } else if (character == ',' && !inQuotes) {
            fields.push_back(Trim(field));
            field.clear();
        } else {
            field.push_back(character);
        }
    }

    if (inQuotes) {
        errorMessage = "Unmatched quotation mark";
        return false;
    }

    fields.push_back(Trim(field));
    return true;
}

bool ParseCourseRecord(const std::string& line,
                       std::size_t lineNumber,
                       Course& course,
                       LoadResult& result) {
    std::vector<std::string> fields;
    std::string parseError;
    if (!ParseCsvFields(line, fields, parseError)) {
        result.hasBlockingRecordErrors = true;
        result.issues.push_back(
            {lineNumber, IssueSeverity::kError, "MalformedCSV", parseError});
        return false;
    }

    if (fields.size() < 2) {
        result.hasBlockingRecordErrors = true;
        result.issues.push_back({lineNumber, IssueSeverity::kError,
                                 "MissingField",
                                 "A course number and title are required"});
        return false;
    }

    course.number = NormalizeCourseCode(fields[0]);
    course.title = Trim(fields[1]);
    course.prerequisites.clear();

    // Invalid primary fields make the entire record unusable because the hash
    // table requires a trustworthy, unique course key.
    if (!IsValidCourseCode(course.number)) {
        result.hasBlockingRecordErrors = true;
        result.issues.push_back(
            {lineNumber, IssueSeverity::kError, "InvalidCourseCode",
             "Invalid course number: " + course.number});
        return false;
    }

    if (course.title.empty()) {
        result.hasBlockingRecordErrors = true;
        result.issues.push_back(
            {lineNumber, IssueSeverity::kError, "MissingField",
             "Course title is empty for " + course.number});
        return false;
    }

    std::unordered_set<std::string> seenPrerequisites;
    for (std::size_t index = 2; index < fields.size(); ++index) {
        const std::string prerequisite = NormalizeCourseCode(fields[index]);
        if (prerequisite.empty()) {
            continue;
        }

        if (!IsValidCourseCode(prerequisite)) {
            result.hasBlockingRecordErrors = true;
            result.issues.push_back(
                {lineNumber, IssueSeverity::kError, "InvalidPrerequisiteCode",
                 "Invalid prerequisite '" + prerequisite + "' for " +
                     course.number});
        }

        if (!seenPrerequisites.insert(prerequisite).second) {
            // Repeated edges would incorrectly increase the prerequisite count
            // during topological sorting, so each relationship is stored once.
            ++result.duplicatePrerequisites;
            result.issues.push_back(
                {lineNumber, IssueSeverity::kWarning, "DuplicatePrerequisite",
                 "Repeated prerequisite '" + prerequisite + "' for " +
                     course.number + " was counted once"});
            continue;
        }
        course.prerequisites.push_back(prerequisite);
    }
    return true;
}

// Relationship validation reports missing and self prerequisites but does not
// delete them. Preserving the original edges prevents the planner from showing
// a misleading course order based on silently repaired data.
void ValidateRelationships(
    const std::unordered_map<std::string, Course>& parsedCourses,
    const std::unordered_map<std::string, std::size_t>& sourceLines,
    LoadResult& result) {
    for (const auto& entry : parsedCourses) {
        const Course& course = entry.second;
        const std::size_t lineNumber = sourceLines.at(course.number);

        for (const std::string& prerequisite : course.prerequisites) {
            if (prerequisite == course.number) {
                ++result.selfPrerequisites;
                result.issues.push_back(
                    {lineNumber, IssueSeverity::kError, "SelfPrerequisite",
                     course.number + " cannot require itself"});
            } else if (parsedCourses.find(prerequisite) == parsedCourses.end()) {
                ++result.missingPrerequisites;
                result.issues.push_back(
                    {lineNumber, IssueSeverity::kError, "MissingPrerequisite",
                     "Prerequisite '" + prerequisite + "' required by " +
                         course.number + " is not defined"});
            }
        }
    }
}

LoadResult LoadCoursesFromFile(const std::string& filePath, HashTable& table) {
    LoadResult result;
    const auto startTime = Clock::now();
    std::ifstream input(filePath);

    if (!input.is_open()) {
        result.issues.push_back({0, IssueSeverity::kError, "FileError",
                                 "Unable to open file: " + filePath});
        return result;
    }
    result.fileOpened = true;

    std::unordered_map<std::string, Course> parsedCourses;
    std::unordered_map<std::string, std::size_t> sourceLines;
    std::string line;
    std::size_t lineNumber = 0;

    while (std::getline(input, line)) {
        ++lineNumber;
        ++result.linesRead;

        const std::string trimmedLine = Trim(line);
        if (trimmedLine.empty() || trimmedLine.front() == '#') {
            ++result.blankLinesSkipped;
            continue;
        }

        Course course;
        if (!ParseCourseRecord(line, lineNumber, course, result)) {
            // The parser has already recorded a line-specific explanation.
            continue;
        }

        // Duplicates are rejected from the temporary collection and marked as
        // blocking because choosing one conflicting definition would be unsafe.
        if (parsedCourses.find(course.number) != parsedCourses.end()) {
            ++result.duplicateCourses;
            result.hasBlockingRecordErrors = true;
            result.issues.push_back(
                {lineNumber, IssueSeverity::kError, "DuplicateCourse",
                 "Duplicate course number: " + course.number});
            continue;
        }

        sourceLines[course.number] = lineNumber;
        parsedCourses.emplace(course.number, std::move(course));
        ++result.parsedCourses;
    }

    // This second pass can validate cross-record relationships only after all
    // course definitions have been collected.
    ValidateRelationships(parsedCourses, sourceLines, result);

    // Load into a fresh table first. Moving the completed table into place
    // avoids mixing records from two files and avoids unsafe pointer copying.
    HashTable replacement(table.BucketCount());
    for (const auto& entry : parsedCourses) {
        if (replacement.Insert(entry.second)) {
            ++result.insertedCourses;
        }
    }
    table = std::move(replacement);

    const auto endTime = Clock::now();
    result.elapsedMilliseconds =
        std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime)
            .count();
    return result;
}

struct CourseOrderResult {
    bool success = false;
    std::vector<Course> orderedCourses;
    std::vector<std::string> errors;
    std::vector<std::string> unresolvedCourses;
};

// -----------------------------------------------------------------------------
// Directed-graph construction and topological sorting
// -----------------------------------------------------------------------------

// Builds an adjacency list with edges prerequisite -> dependent course and
// applies Kahn's algorithm. Graph construction and traversal use O(V + E)
// time and space, where V is courses and E is prerequisite relationships.
CourseOrderResult GenerateCourseOrder(const HashTable& table,
                                      const LoadResult& loadResult) {
    CourseOrderResult result;
    if (table.Empty()) {
        result.errors.push_back(
            "Load course data before generating a course order.");
        return result;
    }

    if (loadResult.hasBlockingRecordErrors) {
        result.errors.push_back(
            "Correct malformed or duplicate course records before planning.");
        return result;
    }

    const std::vector<Course> courses = table.ToVector();

    // courseByNumber supports constant-time access to complete course records.
    // dependents is the adjacency list, and prerequisiteCount is the in-degree
    // collection used by Kahn's algorithm.
    std::unordered_map<std::string, const Course*> courseByNumber;
    std::unordered_map<std::string, std::vector<std::string>> dependents;
    std::unordered_map<std::string, std::size_t> prerequisiteCount;

    courseByNumber.reserve(courses.size());
    dependents.reserve(courses.size());
    prerequisiteCount.reserve(courses.size());

    for (const Course& course : courses) {
        // Initialize every vertex even when it has no incoming or outgoing edge.
        courseByNumber[course.number] = &course;
        dependents[course.number] = {};
        prerequisiteCount[course.number] = 0;
    }

    bool relationshipsAreValid = true;
    for (const Course& course : courses) {
        std::unordered_set<std::string> distinctPrerequisites;
        for (const std::string& prerequisite : course.prerequisites) {
            if (!distinctPrerequisites.insert(prerequisite).second) {
                continue;
            }
            if (prerequisite == course.number) {
                relationshipsAreValid = false;
                result.errors.push_back(course.number + " cannot require itself.");
            } else if (courseByNumber.find(prerequisite) == courseByNumber.end()) {
                relationshipsAreValid = false;
                result.errors.push_back("Missing prerequisite " + prerequisite +
                                        " required by " + course.number + ".");
            } else {
                // The edge points from prerequisite to dependent. The dependent
                // cannot enter the ready queue until all incoming edges clear.
                dependents[prerequisite].push_back(course.number);
                ++prerequisiteCount[course.number];
            }
        }
    }

    if (!relationshipsAreValid) {
        result.errors.push_back(
            "No complete course order was generated from invalid relationships.");
        return result;
    }

    std::queue<std::string> readyCourses;
    for (const Course& course : courses) {
        // Courses with zero incoming edges can be taken immediately.
        if (prerequisiteCount[course.number] == 0) {
            readyCourses.push(course.number);
        }
    }

    while (!readyCourses.empty()) {
        // Removing a ready vertex simulates completing that course. Each
        // outgoing edge is then removed from its dependent course.
        const std::string current = readyCourses.front();
        readyCourses.pop();
        result.orderedCourses.push_back(*courseByNumber.at(current));

        for (const std::string& dependent : dependents[current]) {
            std::size_t& remaining = prerequisiteCount[dependent];
            --remaining;
            if (remaining == 0) {
                // All prerequisites for this dependent have now been processed.
                readyCourses.push(dependent);
            }
        }
    }

    if (result.orderedCourses.size() != courses.size()) {
        // Any vertex with a remaining incoming edge belongs to, or depends on,
        // a cycle. A partial result must not be presented as a complete plan.
        for (const Course& course : courses) {
            if (prerequisiteCount[course.number] > 0) {
                result.unresolvedCourses.push_back(course.number);
            }
        }
        std::sort(result.unresolvedCourses.begin(),
                  result.unresolvedCourses.end());
        result.orderedCourses.clear();
        result.errors.push_back(
            "Circular dependencies prevent a complete course order.");
        return result;
    }

    result.success = true;
    return result;
}

// -----------------------------------------------------------------------------
// Console presentation and application workflow
// -----------------------------------------------------------------------------

void PrintLoadSummary(const LoadResult& result, const HashTable& table) {
    std::cout << "\n=== Load Summary ===\n"
              << "Lines read:             " << result.linesRead << '\n'
              << "Blank/comments skipped: " << result.blankLinesSkipped << '\n'
              << "Courses parsed:         " << result.parsedCourses << '\n'
              << "Courses inserted:       " << result.insertedCourses << '\n'
              << "Duplicate courses:      " << result.duplicateCourses << '\n'
              << "Missing prerequisites:  " << result.missingPrerequisites << '\n'
              << "Self prerequisites:     " << result.selfPrerequisites << '\n'
              << "Duplicate prerequisites:" << result.duplicatePrerequisites << '\n'
              << "Load time:              " << result.elapsedMilliseconds
              << " ms\n";

    if (result.fileOpened) {
        std::cout << "Hash-table load factor: " << std::fixed
                  << std::setprecision(3) << table.LoadFactor() << '\n'
                  << "Hash collisions:        " << table.CollisionCount() << '\n'
                  << "Maximum chain length:   " << table.MaximumChainLength()
                  << '\n';
    }

    if (!result.issues.empty()) {
        std::cout << "\nValidation details:\n";
        for (const LoadIssue& issue : result.issues) {
            std::cout << "- "
                      << (issue.severity == IssueSeverity::kError ? "ERROR" :
                                                                  "WARNING");
            if (issue.lineNumber > 0) {
                std::cout << " [line " << issue.lineNumber << ']';
            }
            std::cout << ' ' << issue.category << ": " << issue.detail << '\n';
        }
    }

    if (result.CanGeneratePlan()) {
        std::cout << "\nRecord and prerequisite-reference validation passed. "
                     "Cycle validation will run when a course order is "
                     "generated.\n";
    } else if (result.fileOpened && result.insertedCourses > 0) {
        std::cout << "\nCourse records are available for review, but validation "
                     "errors must be corrected before generating a plan.\n";
    }
    std::cout << "====================\n\n";
}

void PrintAllCourses(const HashTable& table) {
    if (table.Empty()) {
        std::cout << "No courses are loaded. Use option 1 first.\n\n";
        return;
    }

    const auto startTime = Clock::now();
    const std::vector<Course> courses = table.ToSortedVector();
    const auto endTime = Clock::now();
    const auto elapsed =
        std::chrono::duration_cast<std::chrono::microseconds>(endTime - startTime)
            .count();

    std::cout << "\nCourse Catalog\n--------------\n";
    for (const Course& course : courses) {
        std::cout << course.number << ", " << course.title << '\n';
    }
    std::cout << "\nAlphabetical list generated in " << elapsed
              << " microseconds.\n\n";
}

void PrintCourse(const HashTable& table, const std::string& rawCourseNumber) {
    const std::string courseNumber = NormalizeCourseCode(rawCourseNumber);
    if (!IsValidCourseCode(courseNumber)) {
        std::cout << "Enter a valid course number such as CS300 or CSCI200.\n\n";
        return;
    }

    const Course* course = table.Search(courseNumber);
    if (course == nullptr) {
        std::cout << "Course not found: " << courseNumber << "\n\n";
        return;
    }

    std::cout << '\n' << course->number << ", " << course->title << '\n';
    if (course->prerequisites.empty()) {
        std::cout << "Prerequisites: None\n\n";
        return;
    }

    std::cout << "Prerequisites:\n";
    for (const std::string& prerequisite : course->prerequisites) {
        const Course* prerequisiteCourse = table.Search(prerequisite);
        if (prerequisiteCourse != nullptr) {
            std::cout << "  - " << prerequisiteCourse->number << ": "
                      << prerequisiteCourse->title << '\n';
        } else {
            std::cout << "  - " << prerequisite << ": [course not found]\n";
        }
    }
    std::cout << '\n';
}

void PrintCourseOrder(const HashTable& table, const LoadResult& loadResult) {
    // Timing is informational and helps connect the implementation to the
    // runtime analysis discussed in the enhancement narrative.
    const auto startTime = Clock::now();
    const CourseOrderResult order = GenerateCourseOrder(table, loadResult);
    const auto endTime = Clock::now();
    const auto elapsed =
        std::chrono::duration_cast<std::chrono::microseconds>(endTime - startTime)
            .count();

    if (!order.success) {
        std::cout << "\nUnable to generate a complete course order:\n";
        for (const std::string& error : order.errors) {
            std::cout << "- " << error << '\n';
        }
        if (!order.unresolvedCourses.empty()) {
            std::cout << "Unresolved courses:";
            for (const std::string& course : order.unresolvedCourses) {
                std::cout << ' ' << course;
            }
            std::cout << '\n';
        }
        std::cout << '\n';
        return;
    }

    std::cout << "\nSuggested Prerequisite-Respecting Course Order\n"
              << "-----------------------------------------------\n";
    for (std::size_t index = 0; index < order.orderedCourses.size(); ++index) {
        const Course& course = order.orderedCourses[index];
        std::cout << std::setw(3) << index + 1 << ". " << course.number << ", "
                  << course.title << '\n';
    }
    std::cout << "\nThis order respects prerequisite relationships but does not "
                 "assign semesters or account for course availability or "
                 "credit limits.\n"
              << "Topological order generated in " << elapsed
              << " microseconds.\n\n";
}

void PrintHelp() {
    std::cout
        << "\nHelp\n----\n"
        << "1. Load Course Data - Load and validate a CSV course file.\n"
        << "2. Print Course List - Display courses alphabetically.\n"
        << "3. Print Course - Display one course and its prerequisites.\n"
        << "4. Generate Course Order - Place prerequisites before dependents.\n"
        << "9. Exit - Close the application.\n"
        << "Enter H or ? at the menu to display this help.\n\n";
}

void RunApplication() {
    HashTable table;
    LoadResult latestLoad;
    bool loadAttempted = false;

    std::cout << "Welcome to the Capstone Course Planning Assistant.\n";

    while (true) {
        std::cout << "\n  1. Load Course Data\n"
                  << "  2. Print Course List\n"
                  << "  3. Print Course\n"
                  << "  4. Generate Prerequisite-Respecting Course Order\n"
                  << "  9. Exit\n\n"
                  << "What would you like to do? ";

        std::string choice;
        if (!std::getline(std::cin, choice)) {
            std::cout << "\nInput closed. Exiting the application.\n";
            break;
        }
        choice = Trim(choice);

        if (choice == "1") {
            std::cout << "Enter the course data file path: ";
            std::string filePath;
            if (!std::getline(std::cin, filePath)) {
                std::cout << "\nInput closed. Exiting the application.\n";
                break;
            }
            filePath = Trim(filePath);
            if (filePath.empty()) {
                std::cout << "A file path is required.\n";
                continue;
            }

            latestLoad = LoadCoursesFromFile(filePath, table);
            loadAttempted = true;
            PrintLoadSummary(latestLoad, table);
        } else if (choice == "2") {
            PrintAllCourses(table);
        } else if (choice == "3") {
            if (table.Empty()) {
                std::cout << "Load course data before searching.\n";
                continue;
            }
            std::cout << "Enter a course number (or press Enter to cancel): ";
            std::string courseNumber;
            if (!std::getline(std::cin, courseNumber)) {
                std::cout << "\nInput closed. Exiting the application.\n";
                break;
            }
            if (Trim(courseNumber).empty()) {
                std::cout << "Search cancelled.\n";
                continue;
            }
            PrintCourse(table, courseNumber);
        } else if (choice == "4") {
            // Generation is intentionally separate from loading so users can
            // review validation results before requesting an academic plan.
            if (!loadAttempted) {
                std::cout << "Load course data before generating an order.\n";
                continue;
            }
            PrintCourseOrder(table, latestLoad);
        } else if (choice == "9") {
            std::cout << "Thank you for using the Capstone Course Planning "
                         "Assistant.\n";
            break;
        } else if (choice == "H" || choice == "h" || choice == "?") {
            PrintHelp();
        } else {
            std::cout << "'" << choice
                      << "' is not a valid option. Enter H for help.\n";
        }
    }
}

}  // namespace advising

int main() {
    advising::RunApplication();
    return 0;
}
