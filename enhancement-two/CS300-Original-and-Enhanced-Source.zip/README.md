# CS 499 Enhancement Two: Algorithms and Data Structures

This folder contains the original and enhanced versions of the CS 300 course-planning artifact used for the algorithms and data structures category of the CS 499 capstone.

## Included files

- `ProjectTwoCS300.cpp` — original CS 300 artifact.
- `CS300_Capstone_Enhanced.cpp` — enhanced C++17 implementation.
- `test_valid_courses.csv` — valid prerequisite graph.
- `test_cycle_courses.csv` — circular-dependency test.
- `test_invalid_prerequisites.csv` — missing and self-referencing prerequisite test.
- `test_duplicate_malformed.csv` — duplicate and malformed record test.
- `CS 300 Algorithms and Data Structures Enhancement Narrative.docx` — final enhancement narrative with embedded verification evidence.
- `Evidence/Screenshots/` — original-resolution test screenshots.

## Enhancement summary

The enhanced application preserves the custom hash table for course storage and lookup, then models prerequisites as a directed graph. It uses Kahn's topological-sort algorithm with an adjacency list, incoming-edge counts, and a queue to generate a prerequisite-respecting course order. Graph construction and traversal require `O(V + E)` time and `O(V + E)` additional space, where `V` is the number of courses and `E` is the number of prerequisite relationships.

The loader also reports duplicate courses, repeated prerequisite edges, malformed records, invalid course codes, missing prerequisites, and self-dependencies. Course-order generation is blocked when invalid relationships could make the recommendation unreliable, and cycles are reported with unresolved course codes.

## Build and run

```bash
clang++ -std=c++17 -Wall -Wextra -Wpedantic -Werror CS300_Capstone_Enhanced.cpp -o cs300_enhanced
./cs300_enhanced
```

Inside the program, select option `1`, enter one of the CSV test-file names, and select option `4` to generate or validate the course order. Select option `9` to exit.

## Runtime-safety check

```bash
clang++ -std=c++17 -Wall -Wextra -Wpedantic \
  -fsanitize=address,undefined -fno-omit-frame-pointer \
  CS300_Capstone_Enhanced.cpp -o cs300_sanitized
./cs300_sanitized
```

The narrative documents the design decisions, Big-O analysis, course-outcome connections, validation behavior, trade-offs, and observed test results.
